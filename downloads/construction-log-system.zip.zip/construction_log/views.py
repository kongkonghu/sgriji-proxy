import json
import traceback
import requests
import zipfile
import io
from datetime import datetime
from django.http import JsonResponse, HttpResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods
from django.shortcuts import render, get_object_or_404
from django.conf import settings
from django.db import IntegrityError, OperationalError, InterfaceError
from .models import ConstructionLog, WeChatUser, OperationLog, LogVersion
from django.db.models import Q

# ========== 数据安全保障：审计与限流工具 ==========
import hashlib
from django.db import transaction
from django.core.cache import cache
from .models import OperationLog

def get_client_ip(request):
    '''获取客户端真实IP（支持反向代理）'''
    x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
    if x_forwarded_for:
        ip = x_forwarded_for.split(',')[0].strip()
    else:
        ip = request.META.get('REMOTE_ADDR', '')
    return ip



def create_version_snapshot(log, snapshot_data, user_info, change_summary='', ip=''):
    """Create version snapshot using dict data captured BEFORE transaction."""
    MAX_VERSIONS = 30
    try:
        last_version = LogVersion.objects.filter(log=log).order_by('-version_no').first()
        version_no = (last_version.version_no + 1) if last_version else 1

        LogVersion.objects.create(
            log=log,
            version_no=version_no,
            project_name=snapshot_data.get('project_name', ''),
            log_date=snapshot_data.get('log_date'),
            construction_unit=snapshot_data.get('construction_unit', ''),
            weather_location=snapshot_data.get('weather_location', ''),
            weather_day=snapshot_data.get('weather_day', ''),
            weather_night=snapshot_data.get('weather_night', ''),
            wind_level=snapshot_data.get('wind_level', ''),
            temp_high=snapshot_data.get('temp_high', ''),
            temp_low=snapshot_data.get('temp_low', ''),
            weather_remark=snapshot_data.get('weather_remark', ''),
            special_situation=snapshot_data.get('special_situation', ''),
            study_prepare=snapshot_data.get('study_prepare', ''),
            progress=snapshot_data.get('progress', ''),
            machinery=snapshot_data.get('machinery', ''),
            in_out=snapshot_data.get('in_out', ''),
            other_problems=snapshot_data.get('other_problems', ''),
            scheme_review=snapshot_data.get('scheme_review', ''),
            design_review=snapshot_data.get('design_review', ''),
            contact_sheet=snapshot_data.get('contact_sheet', ''),
            material_test=snapshot_data.get('material_test', ''),
            quality_check=snapshot_data.get('quality_check', ''),
            hidden_check=snapshot_data.get('hidden_check', ''),
            acceptance=snapshot_data.get('acceptance', ''),
            inspection=snapshot_data.get('inspection', ''),
            meeting=snapshot_data.get('meeting', ''),
            quality_safety=snapshot_data.get('quality_safety', ''),
            special_method=snapshot_data.get('special_method', ''),
            visa=snapshot_data.get('visa', ''),
            activities=snapshot_data.get('activities', ''),
            accident=snapshot_data.get('accident', ''),
            recorder=snapshot_data.get('recorder', ''),
            record_date=snapshot_data.get('record_date'),
            editor_openid=user_info.get('openid', ''),
            editor_name=user_info.get('name', ''),
            change_summary=change_summary[:1000],
            ip_address=ip,
        )

        total = LogVersion.objects.filter(log=log).count()
        if total > MAX_VERSIONS:
            to_delete = LogVersion.objects.filter(log=log).order_by('version_no')[:total - MAX_VERSIONS]
            deleted_count = to_delete.count()
            to_delete.delete()
            if deleted_count > 0:
                print(f'VERSION CLEANUP: log={log.id}, deleted={deleted_count}, keep={MAX_VERSIONS}')

        return version_no
    except Exception as e:
        print('VERSION SNAPSHOT ERROR:', e)
        return None


def fetch_weather_for_city(city_code):
    """根据中国天气网获取指定城市的实时天气。city_code为行政区划代码，内部映射到天气网代码。"""
    # 行政区划代码 -> 中国天气网城市代码 映射（可扩展）
    CITY_CODE_MAP = {
        '610802': '101110401',  # 榆林市榆阳区
        '610800': '101110401',  # 榆林市
        '610801': '101110401',  # 榆林市市辖区
        '610100': '101110101',  # 西安市
        '610104': '101110101',  # 西安市莲湖区
        '610113': '101110101',  # 西安市雁塔区
        '610102': '101110101',  # 西安市新城区
        '610103': '101110101',  # 西安市碑林区
        '610111': '101110101',  # 西安市灞桥区
        '610112': '101110101',  # 西安市未央区
        '610116': '101110101',  # 西安市长安区
        '610117': '101110101',  # 西安市高陵区
        '610118': '101110101',  # 西安市鄠邑区
        '610122': '101110101',  # 西安市蓝田县
        '610124': '101110101',  # 西安市周至县
        '610200': '101111001',  # 铜川市
        '610300': '101110901',  # 宝鸡市
        '610400': '101110200',  # 咸阳市
        '610500': '101110501',  # 渭南市
        '610600': '101110300',  # 延安市
        '610700': '101110801',  # 汉中市
        '610900': '101110601',  # 安康市
        '611000': '101110701',  # 商洛市
        '610803': '101110401',  # 榆林市横山区
        '610804': '101110401',  # 榆林市府谷县
        '610825': '101110401',  # 榆林市定边县
        '610826': '101110401',  # 榆林市绥德县
        '610827': '101110401',  # 榆林市米脂县
        '610828': '101110401',  # 榆林市佳县
        '610829': '101110401',  # 榆林市吴堡县
        '610830': '101110401',  # 榆林市清涧县
        '610831': '101110401',  # 榆林市子洲县
        '610821': '101110401',  # 榆林市神木市
        '610822': '101110401',  # 榆林市靖边县
    }

    weather_code = CITY_CODE_MAP.get(city_code, '101110401')  # 默认榆林

    try:
        # 中国天气网实时天气API
        url = f"http://www.weather.com.cn/data/sk/{weather_code}.html"
        resp = requests.get(url, timeout=5, headers={'User-Agent': 'Mozilla/5.0'})
        if resp.status_code == 200:
            data = resp.json()
            info = data.get('weatherinfo', {})
            return {
                'weather_day': info.get('weather', ''),
                'weather_night': info.get('weather', ''),  # 实时接口只有当前天气
                'temp_high': info.get('temp', ''),
                'temp_low': info.get('temp', ''),  # 实时接口只有当前温度
                'wind_level': info.get('WD', '') + info.get('WS', ''),
                'success': True,
            }
    except Exception as e:
        print(f'WEATHER FETCH ERROR for {city_code}: {e}')

    # 备用：尝试多天预报接口获取高低温
    try:
        url2 = f"http://m.weather.com.cn/data/{weather_code}.html"
        resp2 = requests.get(url2, timeout=5, headers={'User-Agent': 'Mozilla/5.0'})
        if resp2.status_code == 200:
            data2 = resp2.json()
            info2 = data2.get('weatherinfo', {})
            return {
                'weather_day': info2.get('weather1', ''),
                'weather_night': info2.get('weather2', ''),
                'temp_high': info2.get('temp1', '').split('~')[0].replace('℃', '') if '~' in info2.get('temp1', '') else info2.get('temp1', '').replace('℃', ''),
                'temp_low': info2.get('temp1', '').split('~')[1].replace('℃', '') if '~' in info2.get('temp1', '') else '',
                'wind_level': info2.get('wind1', ''),
                'success': True,
            }
    except Exception as e:
        print(f'WEATHER FETCH ERROR2 for {city_code}: {e}')

    return {'success': False}


def log_operation(request, action, project_name='', log_date=None, log_id=None, detail=''):
    '''记录操作审计日志。失败静默，不影响主流程'''
    try:
        user = get_current_user(request)
        OperationLog.objects.create(
            user_openid=user.get('openid', '')[:100],
            user_name=user.get('name', '')[:50],
            action=action,
            project_name=project_name[:200],
            log_date=log_date,
            log_id=log_id,
            detail=detail[:2000] if detail else '',
            ip_address=get_client_ip(request),
            user_agent=request.META.get('HTTP_USER_AGENT', '')[:300],
            entry_type=request.GET.get('entry', '')[:10],
        )
    except Exception:
        pass

def rate_limit_check(request, key_prefix, limit=30, period=60):
    '''简易IP限流：period秒内最多limit次。生产环境建议换Redis'''
    try:
        ip = get_client_ip(request)
        key = f"rl:{key_prefix}:{ip}"
        current = cache.get(key, 0)
        if current >= limit:
            return False, f'请求过于频繁，请{period}秒后再试'
        cache.set(key, current + 1, period)
        return True, None
    except Exception:
        return True, None

DIAGONAL_BG = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGQAAABkCAYAAABw4pVUAAACGElEQVR4nO3TWW4EIRAE0cD3v3P7w/Iynq0XoAqIOEFKT1m2bcNyVErZPqJH2FellA1AkAR9Y4Ag4f3F2LatCBLYfwzwIWE9wgBBQnqGAYJ07xUGCNK1dxggSLf2YIAgXdqLAYI07wgGCNK0oxggSLPOYIAgTTqLAYJU7woGCFK1qxggSLVqYIAgVaqFAYJcriYGCHKp2hggyOlaYIAgp2qFAYIcriUGCHKo1hggyO56YIAgu+qFAYK8rScGCPKy3hggyNMiMECQh0VhgCB3RWKAIDdFY4AgP2XAAEGAPBggSCoMWBwkGwYsDJIRAxYFyYoBC4JkxoDFQLJjwEIgI2DAIiCjYMACICNhwOQgo2HAxCAjYsCkIKNiwIQgI2PAZCCjY8BEIDNgwCQgs2DABCAzYcDgILNhwMAgM2LAoCCzYsCAIDNjwGAgs2PAQCArYMAgIKtgwAAgK2FAcpDVMCAxyIoYkBRkVQxICLIyBiQDWR0DEoGI8VUKEDF+CwcR47ZQEDHuCwMR43EhIGI8rzuIGK/rCiLG+7qBiLGvLiBi7K85iBjHagoixvGagYhxriYgYpyvOogY16oKIsb1qoGIUacqIGLU6zKIGHW7BCJG/U6DiNGmUyBitOswiBhtOwQiRvt2g4jRp10gYvTrLYgYfXsJIkb/noKIEdNDEDHiugMRI7YbEDHi+wERI0cfIEamCiBGoj4BHWuK1pLcAZ4AAAAASUVORK5CYII="

def index(request):
    return render(request, 'construction_log/index.html')

def user_entry(request):
    '''用户入口：可填写、读取，不可删除'''
    return render(request, 'construction_log/construction_log_user.html')

def admin_entry(request):
    '''管理员入口：可填写、读取、删除、恢复'''
    return render(request, 'construction_log/construction_log_admin.html')

def _get_json_body(request):
    if hasattr(request, '_parsed_json_body'):
        return request._parsed_json_body
    try:
        if request.body:
            data = json.loads(request.body)
            request._parsed_json_body = data
            return data
    except Exception:
        pass
    return {}


# ==================== 数据库连接异常安全装饰器 ====================
from functools import wraps

def safe_db_query(func):
    """捕获 MySQL 连接丢失异常，返回 JSON 错误而非 HTML 错误页"""
    @wraps(func)
    def wrapper(request, *args, **kwargs):
        try:
            return func(request, *args, **kwargs)
        except (OperationalError, InterfaceError) as e:
            print(f'[DB ERROR] {func.__name__}: {e}')
            traceback.print_exc()
            return JsonResponse({
                'code': 503,
                'status': 'error',
                'msg': '数据库连接中断，请刷新页面后重试',
                'detail': str(e)
            }, status=503)
        except Exception as e:
            print(f'[ERROR] {func.__name__}: {e}')
            traceback.print_exc()
            return JsonResponse({
                'code': 500,
                'status': 'error',
                'msg': '服务器错误: ' + str(e),
                'detail': str(e)
            }, status=500)
    # 关键：复制 Django 视图标记属性（csrf_exempt、require_http_methods 等）
    for attr in ('csrf_exempt', '__wrapped__'):
        if hasattr(func, attr):
            setattr(wrapper, attr, getattr(func, attr))
    return wrapper
# ==================== 装饰器结束 ====================

def get_current_user(request):
    try:
        auth = {}
        if request.method in ('POST', 'PUT', 'DELETE'):
            payload = _get_json_body(request)
            auth = payload.get('auth', {})
        if not auth.get('openid'):
            auth['openid'] = request.GET.get('openid', '')
            auth['name'] = request.GET.get('name', '')
        # session 查询可能触发 MySQL 连接异常，包在 try 内
        try:
            openid = auth.get('openid', '') or request.session.get('wx_openid', '')
            name = auth.get('name', '') or request.session.get('wx_name', '')
        except (OperationalError, InterfaceError):
            openid = auth.get('openid', '')
            name = auth.get('name', '')
        is_admin = False
        if openid:
            try:
                user = WeChatUser.objects.get(openid=openid)
                is_admin = user.is_admin
                if not name and user.name:
                    name = user.name
            except (WeChatUser.DoesNotExist, OperationalError, InterfaceError):
                pass
        return {'openid': openid, 'name': name, 'is_admin': is_admin}
    except Exception as e:
        print(f'[get_current_user ERROR] {e}')
        return {'openid': '', 'name': '', 'is_admin': False}

def check_owner_or_admin(log, user_info):
    if not user_info['openid']:
        return False, '未提供用户身份信息，请在页面顶部设置您的身份'
    # 所有已登录用户均可查看、修改、保存任何日志（协作模式）
    return True, None

@safe_db_query
@require_http_methods(["GET"])
def api_init_db(request):
    from django.db import connection
    from django.contrib.auth.models import User
    from django.core.management import call_command
    import io
    results = []
    try:
        out = io.StringIO()
        try:
            call_command('migrate', '--run-syncdb', stdout=out)
            results.append("Django迁移已执行")
        except Exception as e:
            results.append("Django迁移跳过: " + str(e))
        with connection.cursor() as cursor:
            cursor.execute("SHOW TABLES LIKE 'auth_user'")
            if not cursor.fetchone():
                results.append("auth_user表不存在，尝试创建...")
                try:
                    call_command('migrate', 'auth', stdout=out)
                    results.append("auth迁移已执行")
                except Exception as e:
                    results.append("auth迁移失败: " + str(e))
            else:
                results.append("auth_user表已存在")
            cursor.execute("SHOW TABLES LIKE 'construction_log_wechatuser'")
            wechat_exists = cursor.fetchone() is not None
            if not wechat_exists:
                cursor.execute("""
                    CREATE TABLE construction_log_wechatuser (
                        id bigint AUTO_INCREMENT PRIMARY KEY,
                        openid varchar(100) NOT NULL UNIQUE,
                        unionid varchar(100) DEFAULT NULL,
                        nickname varchar(100) DEFAULT NULL,
                        name varchar(50) DEFAULT NULL,
                        avatar varchar(200) DEFAULT NULL,
                        phone varchar(20) DEFAULT NULL,
                        is_admin tinyint(1) NOT NULL DEFAULT 0,
                        staff_id varchar(50) DEFAULT NULL,
                        created_at datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
                        KEY staff_id (staff_id)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
                """)
                results.append("WeChatUser表已创建")
            else:
                results.append("WeChatUser表已存在")
            cursor.execute("SHOW TABLES LIKE 'construction_log_constructionlog'")
            log_exists = cursor.fetchone() is not None
            if not log_exists:
                cursor.execute("""
                    CREATE TABLE construction_log_constructionlog (
                        id bigint AUTO_INCREMENT PRIMARY KEY,
                        project_name varchar(200) NOT NULL,
                        log_date date NOT NULL,
                        construction_unit varchar(200) NOT NULL DEFAULT '中国石油天然气管道第二工程有限公司',
                        weather_location varchar(20) NOT NULL DEFAULT '610802',
                        weather_day varchar(50) DEFAULT NULL,
                        weather_night varchar(50) DEFAULT NULL,
                        wind_level varchar(50) DEFAULT NULL,
                        temp_high varchar(10) DEFAULT NULL,
                        temp_low varchar(10) DEFAULT NULL,
                        weather_remark varchar(200) DEFAULT NULL,
                        special_situation longtext DEFAULT NULL,
                        study_prepare longtext DEFAULT NULL,
                        progress longtext DEFAULT NULL,
                        machinery longtext DEFAULT NULL,
                        in_out longtext DEFAULT NULL,
                        other_problems longtext DEFAULT NULL,
                        scheme_review longtext DEFAULT NULL,
                        design_review longtext DEFAULT NULL,
                        contact_sheet longtext DEFAULT NULL,
                        material_test longtext DEFAULT NULL,
                        quality_check longtext DEFAULT NULL,
                        hidden_check longtext DEFAULT NULL,
                        acceptance longtext DEFAULT NULL,
                        inspection longtext DEFAULT NULL,
                        meeting longtext DEFAULT NULL,
                        quality_safety longtext DEFAULT NULL,
                        special_method longtext DEFAULT NULL,
                        visa longtext DEFAULT NULL,
                        activities longtext DEFAULT NULL,
                        accident longtext DEFAULT NULL,
                        recorder varchar(50) DEFAULT NULL,
                        record_date date DEFAULT NULL,
                        merge_count int NOT NULL DEFAULT 1,
                        creator_openid varchar(100) DEFAULT NULL,
                        creator_name varchar(50) DEFAULT NULL,
                        created_at datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
                        updated_at datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
                        is_deleted tinyint(1) NOT NULL DEFAULT 0,
                        deleted_at datetime(6) DEFAULT NULL,
                        deleted_by varchar(50) DEFAULT NULL,
                        KEY project_name (project_name),
                        KEY log_date (log_date),
                        KEY creator_openid (creator_openid),
                        KEY is_deleted (is_deleted)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
                """)
                results.append("ConstructionLog表已创建")
            else:
                results.append("ConstructionLog表已存在")
            try:
                cursor.execute("SHOW COLUMNS FROM construction_log_wechatuser")
                columns = [row[0] for row in cursor.fetchall()]
                if 'is_admin' not in columns:
                    cursor.execute("ALTER TABLE construction_log_wechatuser ADD COLUMN is_admin tinyint(1) NOT NULL DEFAULT 0")
                    results.append("is_admin已添加")
                else:
                    results.append("is_admin已存在")
                if 'staff_id' not in columns:
                    cursor.execute("ALTER TABLE construction_log_wechatuser ADD COLUMN staff_id varchar(50) DEFAULT NULL")
                    try:
                        cursor.execute("CREATE INDEX staff_id ON construction_log_wechatuser(staff_id)")
                    except:
                        pass
                    results.append("staff_id已添加")
                else:
                    results.append("staff_id已存在")
            except Exception as e:
                results.append("WeChatUser字段: " + str(e))
            try:
                cursor.execute("SHOW COLUMNS FROM construction_log_constructionlog")
                log_columns = [row[0] for row in cursor.fetchall()]
                for col, sql in [
                    ('creator_openid', "ALTER TABLE construction_log_constructionlog ADD COLUMN creator_openid varchar(100) DEFAULT NULL"),
                    ('creator_name', "ALTER TABLE construction_log_constructionlog ADD COLUMN creator_name varchar(50) DEFAULT NULL"),
                    ('is_deleted', "ALTER TABLE construction_log_constructionlog ADD COLUMN is_deleted tinyint(1) NOT NULL DEFAULT 0"),
                    ('deleted_at', "ALTER TABLE construction_log_constructionlog ADD COLUMN deleted_at datetime(6) DEFAULT NULL"),
                    ('deleted_by', "ALTER TABLE construction_log_constructionlog ADD COLUMN deleted_by varchar(50) DEFAULT NULL"),
                ]:
                    if col not in log_columns:
                        cursor.execute(sql)
                        results.append(col + "已添加")
                    else:
                        results.append(col + "已存在")
                for idx, idx_sql in [
                    ('creator_openid', "CREATE INDEX creator_openid ON construction_log_constructionlog(creator_openid)"),
                    ('is_deleted', "CREATE INDEX is_deleted ON construction_log_constructionlog(is_deleted)"),
                ]:
                    try:
                        cursor.execute(idx_sql)
                    except:
                        pass
            except Exception as e:
                results.append("ConstructionLog字段: " + str(e))
            try:
                cursor.execute("INSERT INTO django_migrations (app, name, applied) VALUES ('construction_log', '0003_add_user_admin', NOW()) ON DUPLICATE KEY UPDATE applied=NOW()")
                results.append("迁移记录已更新")
            except Exception as e:
                results.append("迁移记录: " + str(e))
        try:
            admin_user, created = User.objects.update_or_create(
                username='admin',
                defaults={'is_superuser': True, 'is_staff': True, 'is_active': True}
            )
            admin_user.set_password('admin123')
            admin_user.save()
            results.append("管理员已创建/重置 (admin / admin123)")
        except Exception as e:
            results.append("管理员: " + str(e))
        try:
            WeChatUser.objects.update_or_create(
                openid='admin',
                defaults={'name': '系统管理员', 'is_admin': True, 'staff_id': 'admin'}
            )
            results.append("微信管理员已创建 (openid=admin)")
        except Exception as e:
            results.append("微信管理员: " + str(e))
    except Exception as e:
        results.append("错误: " + str(e))
    return HttpResponse('<pre>' + '\n'.join(results) + '</pre>')

@safe_db_query
@csrf_exempt
@require_http_methods(["POST"])
def api_reset_admin(request):
    from django.contrib.auth.models import User
    try:
        payload = _get_json_body(request)
        secret = payload.get('secret', '')
        if secret != 'admin123':
            return JsonResponse({'code': 403, 'msg': '密钥错误'})
        user, created = User.objects.update_or_create(
            username='admin',
            defaults={'is_superuser': True, 'is_staff': True, 'is_active': True}
        )
        user.set_password('admin123')
        user.save()
        WeChatUser.objects.update_or_create(
            openid='admin',
            defaults={'name': '系统管理员', 'is_admin': True, 'staff_id': 'admin'}
        )
        return JsonResponse({'code': 0, 'msg': '管理员已重置为 admin / admin123'})
    except Exception as e:
        return JsonResponse({'code': 500, 'msg': str(e)})

@safe_db_query
@csrf_exempt
def api_user_info(request):
    if request.method == 'GET':
        user = get_current_user(request)
        return JsonResponse({'code': 0, 'data': user})
    try:
        payload = _get_json_body(request)
        openid = payload.get('openid', '').strip()
        name = payload.get('name', '').strip()
        if openid:
            request.session['wx_openid'] = openid
            request.session['wx_name'] = name
            request.session.modified = True
            WeChatUser.objects.update_or_create(
                openid=openid,
                defaults={'name': name, 'staff_id': openid}
            )
        return JsonResponse({'code': 0, 'msg': '身份设置成功', 'data': get_current_user(request)})
    except Exception as e:
        return JsonResponse({'code': 500, 'msg': str(e)})

@safe_db_query
@csrf_exempt
def api_logs(request):
    if request.method == 'GET':
        return api_log_list(request)
    elif request.method == 'POST':
        return api_log_save(request)
    return JsonResponse({'code': 405, 'msg': '方法不允许'})

@safe_db_query
@csrf_exempt
def api_log_item(request, pk):
    if request.method == 'GET':
        return api_log_detail_by_id(request, pk)
    elif request.method == 'PUT':
        return api_log_update(request, pk)
    elif request.method == 'DELETE':
        return api_log_soft_delete(request, pk)
    return JsonResponse({'code': 405, 'msg': '方法不允许'})

@safe_db_query
@csrf_exempt
@require_http_methods(["POST"])
def api_log_save(request):
    """Save/merge construction log with transaction protection, version snapshot and audit log"""
    try:
        payload = _get_json_body(request)
        project = payload.get('projectName', '').strip()
        log_date_raw = payload.get('logDate', '').strip()
        log_date = log_date_raw.replace('/', '-') if log_date_raw else ''
        if not log_date:
            return JsonResponse({'code': 400, 'msg': '记录日期不能为空'})
        user = get_current_user(request)
        if not project or not log_date:
            return JsonResponse({'code': 400, 'msg': '工程名称和记录日期必填'})

        # Rate limit check
        ok, msg = rate_limit_check(request, 'save', limit=20, period=60)
        if not ok:
            return JsonResponse({'code': 429, 'msg': msg})

        # Capture snapshot BEFORE transaction (deep copy of all fields)
        existing_log = ConstructionLog.objects.filter(project_name=project, log_date=log_date, is_deleted=False).first()
        snapshot_data = None
        need_snapshot = False
        changed_fields = []
        if existing_log:
            snapshot_data = {
                'project_name': existing_log.project_name,
                'log_date': existing_log.log_date,
                'construction_unit': existing_log.construction_unit,
                'weather_location': existing_log.weather_location,
                'weather_day': existing_log.weather_day,
                'weather_night': existing_log.weather_night,
                'wind_level': existing_log.wind_level,
                'temp_high': existing_log.temp_high,
                'temp_low': existing_log.temp_low,
                'weather_remark': existing_log.weather_remark,
                'special_situation': existing_log.special_situation,
                'study_prepare': existing_log.study_prepare,
                'progress': existing_log.progress,
                'machinery': existing_log.machinery,
                'in_out': existing_log.in_out,
                'other_problems': existing_log.other_problems,
                'scheme_review': existing_log.scheme_review,
                'design_review': existing_log.design_review,
                'contact_sheet': existing_log.contact_sheet,
                'material_test': existing_log.material_test,
                'quality_check': existing_log.quality_check,
                'hidden_check': existing_log.hidden_check,
                'acceptance': existing_log.acceptance,
                'inspection': existing_log.inspection,
                'meeting': existing_log.meeting,
                'quality_safety': existing_log.quality_safety,
                'special_method': existing_log.special_method,
                'visa': existing_log.visa,
                'activities': existing_log.activities,
                'accident': existing_log.accident,
                'recorder': existing_log.recorder,
                'record_date': existing_log.record_date,
            }

        with transaction.atomic():
            try:
                defaults = {'construction_unit': payload.get('constructionUnit', '中国石油天然气管道第二工程有限公司')}
                log = ConstructionLog.objects.filter(project_name=project, log_date=log_date).first()
                if log:
                    is_new = False
                    action_type = 'UPDATE'
                    if log.is_deleted:
                        log.is_deleted = False
                        log.deleted_at = None
                        log.deleted_by = ''
                        is_new = True
                        action_type = 'CREATE'
                else:
                    log = ConstructionLog.objects.create(
                        project_name=project, log_date=log_date, **defaults
                    )
                    is_new = True
                    action_type = 'CREATE'
            except IntegrityError:
                log = ConstructionLog.objects.filter(project_name=project, log_date=log_date).first()
                if not log:
                    return JsonResponse({'code': 500, 'msg': '创建日志失败，请刷新后重试'})
                is_new = False
                action_type = 'UPDATE'
                if log.is_deleted:
                    log.is_deleted = False
                    log.deleted_at = None
                    log.deleted_by = ''
                    is_new = True
                    action_type = 'CREATE'

            # Mark for version snapshot if existing log and not new
            if existing_log and not is_new:
                need_snapshot = True

            # Merge save logic
            log.construction_unit = payload.get('constructionUnit', '') or log.construction_unit or '中国石油天然气管道第二工程有限公司'
            log.weather_location = payload.get('weatherLocation', '') or log.weather_location or '610802'
            log.weather_day = payload.get('weatherDay', '') or log.weather_day
            log.weather_night = payload.get('weatherNight', '') or log.weather_night
            log.wind_level = payload.get('windLevel', '') or log.wind_level
            log.temp_high = payload.get('tempHigh', '') or log.temp_high
            log.temp_low = payload.get('tempLow', '') or log.temp_low
            log.weather_remark = payload.get('weatherRemark', '') or log.weather_remark
            log.recorder = payload.get('recorder', '') or log.recorder
            record_date_raw = payload.get('recordDate', '').strip()
            log.record_date = record_date_raw.replace('/', '-') or log.record_date or log_date

            field_mapping = {
                'specialSituation': 'special_situation',
                'studyPrepare': 'study_prepare',
                'progress': 'progress',
                'machinery': 'machinery',
                'inOut': 'in_out',
                'otherProblems': 'other_problems',
                'schemeReview': 'scheme_review',
                'designReview': 'design_review',
                'contactSheet': 'contact_sheet',
                'materialTest': 'material_test',
                'qualityCheck': 'quality_check',
                'hiddenCheck': 'hidden_check',
                'acceptance': 'acceptance',
                'inspection': 'inspection',
                'meeting': 'meeting',
                'qualitySafety': 'quality_safety',
                'specialMethod': 'special_method',
                'visa': 'visa',
                'activities': 'activities',
                'accident': 'accident',
            }
            for front_key, back_key in field_mapping.items():
                new_val = (payload.get(front_key) or '').strip()
                if not new_val:
                    continue
                old_val = (getattr(log, back_key) or '').strip()
                if not old_val:
                    setattr(log, back_key, new_val)
                    if need_snapshot:
                        changed_fields.append(back_key)
                else:
                    old_lines = [l.strip() for l in old_val.split('') if l.strip()]
                    new_lines = [l.strip() for l in new_val.split('') if l.strip()]
                    to_add = [l for l in new_lines if l not in old_lines]
                    if to_add:
                        setattr(log, back_key, old_val + '' + '\n' + '\n'.join(to_add))
                        if need_snapshot:
                            changed_fields.append(back_key)

            log.merge_count = 1 if is_new else (log.merge_count or 1) + 1
            if is_new or not log.creator_openid:
                if user['openid']:
                    log.creator_openid = user['openid']
                    log.creator_name = user['name'] or payload.get('recorder', '')
            log.save()

        # Create version snapshot after transaction (for existing logs)
        if need_snapshot and existing_log and snapshot_data:
            snapshot_result = create_version_snapshot(
                existing_log, snapshot_data, user,
                change_summary="修改字段: " + (', '.join(changed_fields) if changed_fields else '基础信息'),
                ip=get_client_ip(request)
            )
            print('VERSION SNAPSHOT: log=' + str(log.id) + ', result=' + str(snapshot_result))

        # Audit log
        detail = "操作人:" + user.get('name','') + " 变更字段:" + (','.join(changed_fields) if changed_fields else '无') + " 合并次数:" + str(log.merge_count)
        log_operation(request, action_type, project, log.log_date, log.id, detail)

        return JsonResponse({
            'code': 0,
            'msg': '保存成功' if is_new else '内容已合并保存',
            'data': {'mergeCount': log.merge_count, 'id': log.id, 'isNew': is_new,
                     'creatorOpenid': log.creator_openid, 'creatorName': log.creator_name}
        })
    except Exception as e:
        tb = traceback.format_exc()
        print('SAVE ERROR:', tb)
        return JsonResponse({'code': 500, 'msg': '服务器错误: ' + str(e), 'detail': str(e), 'traceback': tb})


@safe_db_query
@require_http_methods(["GET"])
def api_log_detail_by_id(request, pk):
    try:
        log = get_object_or_404(ConstructionLog, pk=pk, is_deleted=False)
        data = {
            'id': log.id,
            'projectName': log.project_name,
            'logDate': str(log.log_date),
            'constructionUnit': log.construction_unit,
            'weatherLocation': log.weather_location,
            'weatherDay': log.weather_day,
            'weatherNight': log.weather_night,
            'windLevel': log.wind_level,
            'tempHigh': log.temp_high,
            'tempLow': log.temp_low,
            'weatherRemark': log.weather_remark,
            'recorder': log.recorder,
            'recordDate': str(log.record_date) if log.record_date else str(log.log_date),
            'mergeCount': log.merge_count,
            'specialSituation': log.special_situation,
            'studyPrepare': log.study_prepare,
            'progress': log.progress,
            'machinery': log.machinery,
            'inOut': log.in_out,
            'otherProblems': log.other_problems,
            'schemeReview': log.scheme_review,
            'designReview': log.design_review,
            'contactSheet': log.contact_sheet,
            'materialTest': log.material_test,
            'qualityCheck': log.quality_check,
            'hiddenCheck': log.hidden_check,
            'acceptance': log.acceptance,
            'inspection': log.inspection,
            'meeting': log.meeting,
            'qualitySafety': log.quality_safety,
            'specialMethod': log.special_method,
            'visa': log.visa,
            'activities': log.activities,
            'accident': log.accident,
            'creatorOpenid': log.creator_openid,
            'creatorName': log.creator_name,
        }
        return JsonResponse({'code': 0, 'data': data})
    except Exception as e:
        return JsonResponse({'code': 500, 'msg': str(e)})

@safe_db_query
@csrf_exempt
@require_http_methods(["PUT"])
def api_log_update(request, pk):
    try:
        payload = _get_json_body(request)
        log = get_object_or_404(ConstructionLog, pk=pk, is_deleted=False)
        user = get_current_user(request)
        ok, msg = check_owner_or_admin(log, user)
        if not ok:
            return JsonResponse({'code': 403, 'msg': msg})
        log.project_name = payload.get('projectName', log.project_name)
        log.log_date = payload.get('logDate', log.log_date)
        log.construction_unit = payload.get('constructionUnit', log.construction_unit)
        log.weather_location = payload.get('weatherLocation', log.weather_location)
        log.weather_day = payload.get('weatherDay', log.weather_day)
        log.weather_night = payload.get('weatherNight', log.weather_night)
        log.wind_level = payload.get('windLevel', log.wind_level)
        log.temp_high = payload.get('tempHigh', log.temp_high)
        log.temp_low = payload.get('tempLow', log.temp_low)
        log.weather_remark = payload.get('weatherRemark', log.weather_remark)
        log.recorder = payload.get('recorder', log.recorder)
        log.record_date = payload.get('recordDate', log.record_date)
        log.special_situation = payload.get('specialSituation', log.special_situation)
        log.study_prepare = payload.get('studyPrepare', log.study_prepare)
        log.progress = payload.get('progress', log.progress)
        log.machinery = payload.get('machinery', log.machinery)
        log.in_out = payload.get('inOut', log.in_out)
        log.other_problems = payload.get('otherProblems', log.other_problems)
        log.scheme_review = payload.get('schemeReview', log.scheme_review)
        log.design_review = payload.get('designReview', log.design_review)
        log.contact_sheet = payload.get('contactSheet', log.contact_sheet)
        log.material_test = payload.get('materialTest', log.material_test)
        log.quality_check = payload.get('qualityCheck', log.quality_check)
        log.hidden_check = payload.get('hiddenCheck', log.hidden_check)
        log.acceptance = payload.get('acceptance', log.acceptance)
        log.inspection = payload.get('inspection', log.inspection)
        log.meeting = payload.get('meeting', log.meeting)
        log.quality_safety = payload.get('qualitySafety', log.quality_safety)
        log.special_method = payload.get('specialMethod', log.special_method)
        log.visa = payload.get('visa', log.visa)
        log.activities = payload.get('activities', log.activities)
        log.accident = payload.get('accident', log.accident)
        log.save()
        return JsonResponse({'code': 0, 'msg': '更新成功'})
    except Exception as e:
        return JsonResponse({'code': 500, 'msg': str(e)})

@safe_db_query
@csrf_exempt
@require_http_methods(["DELETE"])
@csrf_exempt
def api_log_soft_delete(request, pk):
    '''软删除到回收站，带审计日志'''
    try:
        entry_type = request.GET.get('entry', '')
        if entry_type == 'user':
            return JsonResponse({'code': 403, 'msg': '用户入口无权删除日志，请使用管理员入口'})

        ok, msg = rate_limit_check(request, 'delete', limit=10, period=60)
        if not ok:
            return JsonResponse({'code': 429, 'msg': msg})

        log = get_object_or_404(ConstructionLog, pk=pk, is_deleted=False)
        user = get_current_user(request)
        ok2, msg2 = check_owner_or_admin(log, user)
        if not ok2:
            return JsonResponse({'code': 403, 'msg': msg2})

        with transaction.atomic():
            log.is_deleted = True
            log.deleted_at = datetime.now()
            log.deleted_by = user['name'] or user['openid']
            log.save()

        log_operation(request, 'SOFT_DELETE', log.project_name, log.log_date, log.id,
                      f"删除人:{user.get('name','')}({user.get('openid','')})")
        return JsonResponse({'code': 0, 'msg': '已删除到回收站'})
    except Exception as e:
        return JsonResponse({'code': 500, 'msg': str(e)})
@safe_db_query
@csrf_exempt
def api_log_restore(request, pk):
    '''从回收站恢复，带审计日志'''
    try:
        entry_type = request.GET.get('entry', '')
        if entry_type == 'user':
            return JsonResponse({'code': 403, 'msg': '用户入口无权恢复日志，请使用管理员入口'})

        log = get_object_or_404(ConstructionLog, pk=pk, is_deleted=True)
        user = get_current_user(request)
        if not user['is_admin']:
            return JsonResponse({'code': 403, 'msg': '仅管理员可恢复日志'})

        with transaction.atomic():
            log.is_deleted = False
            log.deleted_at = None
            log.deleted_by = ''
            log.save()

        log_operation(request, 'RESTORE', log.project_name, log.log_date, log.id,
                      f"恢复人:{user.get('name','')}({user.get('openid','')})")
        return JsonResponse({'code': 0, 'msg': '已恢复'})
    except Exception as e:
        return JsonResponse({'code': 500, 'msg': str(e)})

@safe_db_query
@csrf_exempt
def api_log_hard_delete(request, pk):
    '''彻底删除（支持单条或批量），带审计日志'''
    try:
        entry_type = request.GET.get('entry', '')
        if entry_type == 'user':
            return JsonResponse({'code': 403, 'msg': '用户入口无权彻底删除日志，请使用管理员入口'})

        ok, msg = rate_limit_check(request, 'hard_delete', limit=5, period=60)
        if not ok:
            return JsonResponse({'code': 429, 'msg': msg})

        user = get_current_user(request)
        if not user['is_admin']:
            return JsonResponse({'code': 403, 'msg': '仅管理员可彻底删除'})

        # 批量删除支持：?ids=1,2,3
        ids_param = request.GET.get('ids', '').strip()
        if ids_param:
            id_list = [int(x) for x in ids_param.split(',') if x.strip().isdigit()]
            logs = ConstructionLog.objects.filter(pk__in=id_list, is_deleted=True)
            deleted_count = 0
            with transaction.atomic():
                for log in logs:
                    log_operation(request, 'HARD_DELETE', log.project_name, log.log_date, log.id,
                                  f"彻底删除人:{user.get('name','')} 原删除人:{log.deleted_by or '未知'}")
                    log.delete()
                    deleted_count += 1
            return JsonResponse({'code': 0, 'msg': f'已彻底删除 {deleted_count} 条日志'})
        else:
            log = get_object_or_404(ConstructionLog, pk=pk, is_deleted=True)
            with transaction.atomic():
                log_operation(request, 'HARD_DELETE', log.project_name, log.log_date, log.id,
                              f"彻底删除人:{user.get('name','')} 原删除人:{log.deleted_by or '未知'}")
                log.delete()
            return JsonResponse({'code': 0, 'msg': '已彻底删除'})
    except Exception as e:
        return JsonResponse({'code': 500, 'msg': str(e)})
@safe_db_query
def api_log_list(request):
    user = get_current_user(request)
    project = request.GET.get('project', '').strip()
    qs = ConstructionLog.objects.filter(is_deleted=False)
    if project:
        qs = qs.filter(project_name__icontains=project)
    qs = qs.order_by('-log_date')[:50]
    data = [{
        'id': l.id,
        'projectName': l.project_name,
        'logDate': str(l.log_date),
        'recorder': l.recorder,
        'constructionUnit': l.construction_unit,
        'mergeCount': l.merge_count,
        'creatorOpenid': l.creator_openid,
        'creatorName': l.creator_name,
        'updatedAt': l.updated_at.strftime('%m-%d %H:%M') if l.updated_at else ''
    } for l in qs]
    return JsonResponse({'code': 0, 'data': data, 'isAdmin': user['is_admin']})

@safe_db_query
@require_http_methods(["GET"])
@require_http_methods(["GET"])
def api_log_recycle_bin(request):
    try:
        # 检查入口类型 - 用户入口禁止查看回收站
        entry_type = request.GET.get('entry', '')
        if entry_type == 'user':
            return JsonResponse({'code': 403, 'msg': '用户入口无权查看回收站'})

        user = get_current_user(request)
        if not user['is_admin']:
            return JsonResponse({'code': 403, 'msg': '仅管理员可查看回收站'})
        logs = ConstructionLog.objects.filter(is_deleted=True).order_by('-deleted_at')
        data = [{
            'id': log.id,
            'projectName': log.project_name,
            'logDate': str(log.log_date),
            'deletedAt': log.deleted_at.strftime('%Y-%m-%d %H:%M') if log.deleted_at else '',
            'deletedBy': log.deleted_by,
            'creatorName': log.creator_name,
        } for log in logs]
        return JsonResponse({'code': 0, 'data': data})
    except Exception as e:
        return JsonResponse({'code': 500, 'msg': str(e)})
@safe_db_query
def api_log_projects(request):
    projects = ConstructionLog.objects.filter(is_deleted=False).values_list('project_name', flat=True).distinct()
    return JsonResponse({'code': 0, 'data': list(projects)})

@safe_db_query
@require_http_methods(["GET"])
@csrf_exempt
def api_export_project_zip(request):
    project = request.GET.get('project', '').strip()
    if not project:
        return JsonResponse({'code': 400, 'msg': '工程名称必填'})
    logs = ConstructionLog.objects.filter(project_name=project, is_deleted=False).order_by('log_date')
    if not logs.exists():
        return JsonResponse({'code': 404, 'msg': '该工程暂无日志记录'})
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, 'w', zipfile.ZIP_DEFLATED) as zf:
        for log in logs:
            html = build_log_word_html(log)
            filename = f"{log.log_date}_{log.project_name[:20]}.doc"
            zf.writestr(filename, html.encode('utf-8'))
    buffer.seek(0)
    response = HttpResponse(buffer.read(), content_type='application/zip')
    response['Content-Disposition'] = f'attachment; filename="{project}_施工日志.zip"'
    return response


@safe_db_query
@csrf_exempt
def api_export_excel(request):
    # 导出CSV格式, 无需安装openpyxl, 同样可导入Word邮件合并
    log_id = request.GET.get('id')
    project = request.GET.get('project', '').strip()
    log_ids = request.GET.get('ids', '').strip()

    if log_ids:
        id_list = [int(x) for x in log_ids.split(',') if x.strip().isdigit()]
        logs = ConstructionLog.objects.filter(id__in=id_list, is_deleted=False).order_by('log_date')
    elif log_id:
        logs = ConstructionLog.objects.filter(id=log_id, is_deleted=False)
    elif project:
        logs = ConstructionLog.objects.filter(project_name=project, is_deleted=False).order_by('log_date')
    else:
        return JsonResponse({'code': 400, 'msg': '请提供日志ID或工程名称'})

    if not logs.exists():
        return JsonResponse({'code': 404, 'msg': '未找到日志记录'})

    import csv
    response = HttpResponse(content_type='text/csv; charset=utf-8-sig')
    filename = "施工日志_" + (project or str(log_id) or '导出') + "_" + datetime.now().strftime('%Y%m%d') + ".csv"
    response['Content-Disposition'] = 'attachment; filename="' + filename + '"'

    writer = csv.writer(response)
    # 写入表头 - 只包含模型中实际存在的字段
    writer.writerow([
        '工程名称', '施工单位', '记录日期', '天气地点',
        '白天天气', '夜间天气', '最高温度', '最低温度', '风力', '备注',
        '记录人', '记录日期2',
        '1.停水停电停工待料', '2.图纸规范学习', '3.项目进度情况', '4.机械班组情况',
        '5.材料进出情况', '6.质量安全检查', '7.方案审查', '8.设计交底', '9.洽商记录', '10.其他事项',
        '1.材料试验', '2.质量检查', '3.隐蔽验收', '4.检验验收', '5.安全教育', '6.安全会议',
        '7.特种作业', '8.现场签证', '9.文明施工', '10.安全事故'
    ])

    for log in logs:
        writer.writerow([
            log.project_name or '',
            log.construction_unit or '中国石油天然气管道第二工程有限公司',
            str(log.log_date) if log.log_date else '',
            log.weather_location or '榆林市榆阳区',
            log.weather_day or '',
            log.weather_night or '',
            log.temp_high or '',
            log.temp_low or '',
            log.wind_level or '',
            log.weather_remark or '',
            log.recorder or '',
            str(log.record_date) if log.record_date else '',
            log.special_situation or '',
            log.study_prepare or '',
            log.progress or '',
            log.machinery or '',
            log.in_out or '',
            log.quality_safety or '',
            log.scheme_review or '',
            log.design_review or '',
            log.contact_sheet or '',
            log.other_problems or '',
            log.material_test or '',
            log.quality_check or '',
            log.hidden_check or '',
            log.acceptance or '',
            log.inspection or '',
            log.meeting or '',
            log.special_method or '',
            log.visa or '',
            log.activities or '',
            log.accident or ''
        ])

    return response

def build_log_word_html(log):
    def esc(s):
        if not s:
            return ''
        return s.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;').replace('"', '&quot;')
    def fmt_date(d):
        p = (d or '').split('-')
        return p[0] + '.' + p[1] + '.' + p[2] if len(p) == 3 else (d or '')
    def get(k):
        return (getattr(log, k, None) or '').strip()
    city_name = {
        "610802": "榆林市榆阳区", "610803": "榆林市横山区", "610881": "榆林市神木市",
        "610822": "榆林市府谷县", "610824": "榆林市靖边县", "610825": "榆林市定边县",
        "610826": "榆林市绥德县", "610827": "榆林市米脂县", "610828": "榆林市佳县",
        "610829": "榆林市吴堡县", "610830": "榆林市清涧县", "610831": "榆林市子洲县"
    }.get(get('weather_location'), '榆林市')
    prod_fields = [
        ('special_situation', '停水、停电、停工待料等特殊情况'),
        ('study_prepare', '图纸、规范的学习情况，施工准备情况'),
        ('progress', '项目进度情况，具体作业内容、工艺、整体完成情况'),
        ('machinery', '机械情况、班组人员情况'),
        ('in_out', '人员、材料、机械、设备等进出场情况'),
        ('other_problems', '生产方面存在的其他问题')
    ]
    tech_fields = [
        ('scheme_review', '施工方案、质量技术交底、安全技术交底、质量计划等审核审批情况'),
        ('design_review', '参加的设计交底、图纸会审等相关活动'),
        ('contact_sheet', '上报的工程联络单审核审批情况'),
        ('material_test', '原材料进场第三方复检见证取样及复检结果'),
        ('quality_check', '各类质量实施情况'),
        ('hidden_check', '现场隐蔽验收情况'),
        ('acceptance', '分部分项工程、检验批质量验收，单位工程验收情况'),
        ('inspection', '接受上级部门的检查，项目大事记'),
        ('meeting', '参加监理、设计、业主组织的各类会议及简要内容'),
        ('quality_safety', '现场质量、安全等方面存在的问题，及整改回复情况'),
        ('special_method', '紧急或特殊情况下的特殊施工方法、技术措施记录'),
        ('visa', '认质认价、签证单等申请审核审批情况'),
        ('activities', '当日质量、安全各类活动'),
        ('accident', '质量、安全事故记录')
    ]
    prod_body = '<p style="margin:4pt 0; font-weight:bold; font-family:宋体,SimSun;">生产情况记录：</p>'
    prod_seq = 1
    for field, label in prod_fields:
        val = (getattr(log, field, None) or '').strip()
        if val:
            prod_body += '<p style="margin:2pt 0; font-size:11pt; line-height:1.5; font-family:宋体,SimSun;">' + str(prod_seq) + '.' + esc(val).replace(chr(10), '<br>') + '</p>'
            prod_seq += 1
    tech_body = '<p style="margin:4pt 0; font-weight:bold; font-family:宋体,SimSun;">技术质量安全工作记录：</p>'
    tech_seq = 1
    for field, label in tech_fields:
        val = (getattr(log, field, None) or '').strip()
        if val:
            tech_body += '<p style="margin:2pt 0; font-size:11pt; line-height:1.5; font-family:宋体,SimSun;">' + str(tech_seq) + '.' + esc(val).replace(chr(10), '<br>') + '</p>'
            tech_seq += 1
    html_parts = []
    html_parts.append('<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40">')
    html_parts.append('<head><meta charset="utf-8"><title>施工日志</title>')
    html_parts.append('<!--[if gte mso 9]>')
    html_parts.append('<xml>')
    html_parts.append('  <w:WordDocument>')
    html_parts.append('    <w:View>Print</w:View>')
    html_parts.append('    <w:Zoom>100</w:Zoom>')
    html_parts.append('    <w:DoNotOptimizeForBrowser/>')
    html_parts.append('    <w:Compatibility>')
    html_parts.append('      <w:BreakWrappedTables/>')
    html_parts.append('      <w:SnapToGridInCell/>')
    html_parts.append('      <w:WrapTextWithPunct/>')
    html_parts.append('      <w:AsianBreakRules/>')
    html_parts.append('      <w:UseWord97LineBreakingRules/>')
    html_parts.append('    </w:Compatibility>')
    html_parts.append('  </w:WordDocument>')
    html_parts.append('</xml>')
    html_parts.append('<![endif]-->')
    html_parts.append('<style>')
    html_parts.append('@page Section1 { size: 595.3pt 841.9pt; margin: 2cm 2cm 2cm 2.5cm; mso-page-orientation: portrait; mso-header-margin: 42.55pt; mso-footer-margin: 49.6pt; mso-paper-source: 0; }')
    html_parts.append('div.Section1 { page: Section1; }')
    html_parts.append('body { font-family: "宋体", SimSun, serif; font-size: 11pt; margin: 0; }')
    html_parts.append('table { width: 100%; border-collapse: collapse; font-size: 11pt; table-layout: fixed; border: 1px solid #000; }')
    html_parts.append('td { border: 1px solid #000; padding: 3pt 4pt; vertical-align: middle; word-wrap: break-word; }')
    html_parts.append('</style></head><body><div class="Section1">')
    html_parts.append('<p style="text-align:center; font-family:宋体,SimSun; font-size:16pt; font-weight:bold; margin-bottom:6pt;">施工日志</p>')
    html_parts.append('<table border="1" cellspacing="0" cellpadding="0" style="width:100%; border-collapse:collapse; font-size:11pt; table-layout:fixed; border:1px solid #000;">')
    html_parts.append('  <tr>')
    html_parts.append('    <td style="width:15%; font-weight:bold; font-family:宋体,SimSun; font-size:10pt; text-align:center; border:1px solid #000; padding:3pt 4pt;">工程名称</td>')
    html_parts.append('    <td style="width:35%; font-size:11pt; border:1px solid #000; padding:3pt 4pt; font-family:宋体,SimSun;">' + esc(get("project_name")) + '</td>')
    html_parts.append('    <td style="width:15%; font-weight:bold; font-family:宋体,SimSun; font-size:10pt; text-align:center; border:1px solid #000; padding:3pt 4pt;">施工单位</td>')
    html_parts.append('    <td colspan="2" style="width:35%; font-size:11pt; border:1px solid #000; padding:3pt 4pt; font-family:宋体,SimSun;">' + esc(get("construction_unit")) + '</td>')
    html_parts.append('  </tr>')
    html_parts.append('  <tr>')
    html_parts.append('    <td style="width:15%; font-weight:bold; font-family:宋体,SimSun; font-size:10pt; text-align:center; border:1px solid #000; padding:3pt 4pt;">记录日期</td>')
    html_parts.append('    <td style="width:35%; font-size:11pt; border:1px solid #000; padding:3pt 4pt; font-family:宋体,SimSun;">' + fmt_date(get("log_date")) + '</td>')
    html_parts.append('    <td style="width:15%; font-weight:bold; font-family:宋体,SimSun; font-size:10pt; text-align:center; border:1px solid #000; padding:3pt 4pt;">天气地点</td>')
    html_parts.append('    <td colspan="2" style="width:35%; font-size:11pt; border:1px solid #000; padding:3pt 4pt; font-family:宋体,SimSun;">' + esc(city_name) + '</td>')
    html_parts.append('  </tr>')
    html_parts.append('  <tr>')
    html_parts.append('    <td style="position:relative; height:40pt; border:1px solid #000; overflow:hidden; padding:0; background-image: url(' + DIAGONAL_BG + '); background-size: 100% 100%; background-repeat: no-repeat;">')
    html_parts.append('      <div style="position:absolute; top:2px; right:4px; font-size:10pt; font-family:宋体,SimSun; z-index:2;">项目</div>')
    html_parts.append('      <div style="position:absolute; bottom:2px; left:4px; font-size:10pt; font-family:宋体,SimSun; z-index:2;">时间</div>')
    html_parts.append('    </td>')
    html_parts.append('    <td style="font-weight:bold; font-family:宋体,SimSun; font-size:10pt; text-align:center; border:1px solid #000; padding:3pt 4pt;">天气状况</td>')
    html_parts.append('    <td style="font-weight:bold; font-family:宋体,SimSun; font-size:10pt; text-align:center; border:1px solid #000; padding:3pt 4pt;">风力</td>')
    html_parts.append('    <td style="font-weight:bold; font-family:宋体,SimSun; font-size:10pt; text-align:center; border:1px solid #000; padding:3pt 4pt;">最高/最低温度</td>')
    html_parts.append('    <td style="font-weight:bold; font-family:宋体,SimSun; font-size:10pt; text-align:center; border:1px solid #000; padding:3pt 4pt;">备注</td>')
    html_parts.append('  </tr>')
    html_parts.append('  <tr>')
    html_parts.append('    <td style="font-weight:bold; font-family:宋体,SimSun; font-size:10pt; text-align:center; border:1px solid #000; padding:3pt 4pt;">白天</td>')
    html_parts.append('    <td style="text-align:center; font-size:11pt; border:1px solid #000; padding:3pt 4pt; font-family:宋体,SimSun;">' + esc(get("weather_day")) + '</td>')
    html_parts.append('    <td style="text-align:center; font-size:11pt; border:1px solid #000; padding:3pt 4pt; font-family:宋体,SimSun;">' + esc(get("wind_level")) + '</td>')
    html_parts.append('    <td style="text-align:center; font-size:11pt; border:1px solid #000; padding:3pt 4pt; font-family:宋体,SimSun;">' + esc(get("temp_high")) + '</td>')
    html_parts.append('    <td style="text-align:center; font-size:11pt; border:1px solid #000; padding:3pt 4pt; font-family:宋体,SimSun;">' + esc(get("weather_remark")) + '</td>')
    html_parts.append('  </tr>')
    html_parts.append('  <tr>')
    html_parts.append('    <td style="font-weight:bold; font-family:宋体,SimSun; font-size:10pt; text-align:center; border:1px solid #000; padding:3pt 4pt;">夜间</td>')
    html_parts.append('    <td style="text-align:center; font-size:11pt; border:1px solid #000; padding:3pt 4pt; font-family:宋体,SimSun;">' + esc(get("weather_night")) + '</td>')
    html_parts.append('    <td style="text-align:center; font-size:11pt; border:1px solid #000; padding:3pt 4pt; font-family:宋体,SimSun;">' + esc(get("wind_level")) + '</td>')
    html_parts.append('    <td style="text-align:center; font-size:11pt; border:1px solid #000; padding:3pt 4pt; font-family:宋体,SimSun;">' + esc(get("temp_low")) + '</td>')
    html_parts.append('    <td></td>')
    html_parts.append('  </tr>')
    html_parts.append('  <tr style="height: 180pt;">')
    html_parts.append('    <td colspan="5" style="font-size:11pt; vertical-align:top; padding:6pt; line-height:1.5; font-family:宋体,SimSun;">' + prod_body + '</td>')
    html_parts.append('  </tr>')
    html_parts.append('  <tr style="height: 260pt;">')
    html_parts.append('    <td colspan="5" style="font-size:11pt; vertical-align:top; padding:6pt; line-height:1.5; font-family:宋体,SimSun;">' + tech_body + '</td>')
    html_parts.append('  </tr>')
    html_parts.append('  <tr>')
    html_parts.append('    <td style="font-weight:bold; font-family:宋体,SimSun; font-size:10pt; text-align:center; border:1px solid #000; padding:3pt 4pt;">记录人</td>')
    html_parts.append('    <td style="font-size:11pt; border:1px solid #000; padding:3pt 4pt; font-family:宋体,SimSun;">' + (esc(get("recorder")) or "—") + '</td>')
    html_parts.append('    <td style="font-weight:bold; font-family:宋体,SimSun; font-size:10pt; text-align:center; border:1px solid #000; padding:3pt 4pt;">日期</td>')
    html_parts.append('    <td colspan="2" style="font-size:11pt; border:1px solid #000; padding:3pt 4pt; font-family:宋体,SimSun;">' + fmt_date(get("record_date") or get("log_date")) + '</td>')
    html_parts.append('  </tr>')
    html_parts.append('</table>')
    html_parts.append('<p style="font-size:10pt; color:#333; margin-top:8pt; font-style:italic; font-family:宋体,SimSun;">说明：本表格由施工单位填写，作为施工单位施工过程管理的可追溯性记录。</p>')
    html_parts.append('</div></body></html>')
    return '\n'.join(html_parts)

@safe_db_query
@require_http_methods(["GET"])
def api_log_detail(request):
    project = request.GET.get('project', '').strip()
    log_date = request.GET.get('date', '').strip()
    if not project or not log_date:
        return JsonResponse({'code': 400, 'msg': '缺少参数'})
    try:
        log = ConstructionLog.objects.filter(project_name=project, log_date=log_date, is_deleted=False).first()
        if not log:
            return JsonResponse({'code': 404, 'msg': '记录不存在'})
        data = {
            'id': log.id,
            'projectName': log.project_name,
            'logDate': str(log.log_date),
            'constructionUnit': log.construction_unit,
            'weatherLocation': log.weather_location,
            'weatherDay': log.weather_day,
            'weatherNight': log.weather_night,
            'windLevel': log.wind_level,
            'tempHigh': log.temp_high,
            'tempLow': log.temp_low,
            'weatherRemark': log.weather_remark,
            'recorder': log.recorder,
            'recordDate': str(log.record_date) if log.record_date else str(log.log_date),
            'mergeCount': log.merge_count,
            'specialSituation': log.special_situation,
            'studyPrepare': log.study_prepare,
            'progress': log.progress,
            'machinery': log.machinery,
            'inOut': log.in_out,
            'otherProblems': log.other_problems,
            'schemeReview': log.scheme_review,
            'designReview': log.design_review,
            'contactSheet': log.contact_sheet,
            'materialTest': log.material_test,
            'qualityCheck': log.quality_check,
            'hiddenCheck': log.hidden_check,
            'acceptance': log.acceptance,
            'inspection': log.inspection,
            'meeting': log.meeting,
            'qualitySafety': log.quality_safety,
            'specialMethod': log.special_method,
            'visa': log.visa,
            'activities': log.activities,
            'accident': log.accident,
        }
        return JsonResponse({'code': 0, 'data': data})
    except Exception as e:
        return JsonResponse({'code': 500, 'msg': str(e)})

@safe_db_query
@csrf_exempt
@require_http_methods(["POST"])
def api_wechat_login(request):
    try:
        payload = _get_json_body(request)
        openid = payload.get('openid', '').strip()
        name = payload.get('name', '').strip()
        if not openid:
            return JsonResponse({'code': 400, 'msg': '缺少openid'})
        user, created = WeChatUser.objects.update_or_create(
            openid=openid,
            defaults={'name': name, 'staff_id': openid}
        )
        request.session['wx_openid'] = openid
        request.session['wx_name'] = name
        request.session.modified = True
        return JsonResponse({
            'code': 0,
            'msg': '登录成功',
            'data': {'openid': openid, 'name': name, 'isAdmin': user.is_admin, 'isNew': created}
        })
    except Exception as e:
        return JsonResponse({'code': 500, 'msg': '登录失败: ' + str(e)})

@safe_db_query
@csrf_exempt
def api_auto_create_log(request):
    '''智能自动创建当天及未来4天的日志（共5天），跳过已存在的'''
    if request.method != 'POST':
        return JsonResponse({'code': 405, 'msg': '仅支持POST'})
    try:
        payload = _get_json_body(request)
        project = payload.get('projectName', '').strip()
        city_code = payload.get('weatherLocation', '610802')
        days = payload.get('days', 5)  # 默认今天+后4天=5天
        force = payload.get('force', False)  # 强制模式：即使已存在也重新创建
        user = get_current_user(request)

        if not project:
            return JsonResponse({'code': 400, 'msg': '工程名称必填'})

        from datetime import datetime, timedelta
        created_logs = []
        skipped_logs = []
        restored_logs = []
        today = datetime.now().date()

        for i in range(days):
            log_date = today + timedelta(days=i)
            log_date_str = log_date.strftime('%Y-%m-%d')

            # 查找包括已删除的记录（避免唯一约束冲突）
            log = ConstructionLog.objects.filter(project_name=project, log_date=log_date_str).first()
            if log:
                if log.is_deleted:
                    # 恢复已删除的记录
                    log.is_deleted = False
                    log.deleted_at = None
                    log.deleted_by = ''
                    log.save()
                    restored_logs.append(log_date_str)
                else:
                    skipped_logs.append(log_date_str)
            else:
                # 创建新记录
                log = ConstructionLog.objects.create(
                    project_name=project,
                    log_date=log_date_str,
                    construction_unit='中国石油天然气管道第二工程有限公司',
                    weather_location=city_code,
                    creator_openid=user['openid'],
                    creator_name=user['name']
                )
                created_logs.append(log_date_str)

                # 自动获取天气（仅新创建的日志）
                try:
                    weather_data = fetch_weather_for_city(city_code)
                    if weather_data.get('success'):
                        log.weather_day = weather_data.get('weather_day', '')
                        log.weather_night = weather_data.get('weather_night', '')
                        log.temp_high = weather_data.get('temp_high', '')
                        log.temp_low = weather_data.get('temp_low', '')
                        log.wind_level = weather_data.get('wind_level', '')
                        log.save()
                except Exception as e:
                    print(f'AUTO WEATHER ERROR for {log_date_str}: {e}')

        msg_parts = []
        if created_logs:
            msg_parts.append('新建 ' + str(len(created_logs)) + ' 天: ' + ', '.join(created_logs))
        if restored_logs:
            msg_parts.append('恢复 ' + str(len(restored_logs)) + ' 天: ' + ', '.join(restored_logs))
        if skipped_logs:
            msg_parts.append('跳过 ' + str(len(skipped_logs)) + ' 天: ' + ', '.join(skipped_logs))

        return JsonResponse({
            'code': 0,
            'msg': '; '.join(msg_parts) if msg_parts else '所有日期已存在',
            'data': {
                'projectName': project,
                'created': created_logs,
                'restored': restored_logs,
                'skipped': skipped_logs,
                'totalDays': days,
                'today': str(today)
            }
        })
    except Exception as e:
        return JsonResponse({'code': 500, 'msg': str(e)})

@safe_db_query
@csrf_exempt
def api_create_backfill_log(request):
    '''手动补录历史日期的日志'''
    if request.method != 'POST':
        return JsonResponse({'code': 405, 'msg': '仅支持POST'})
    try:
        payload = _get_json_body(request)
        project = payload.get('projectName', '').strip()
        log_date = payload.get('logDate', '').strip().replace('/', '-')
        city_code = payload.get('weatherLocation', '610802')
        user = get_current_user(request)

        if not project or not log_date:
            return JsonResponse({'code': 400, 'msg': '工程名称和记录日期必填'})

        from datetime import datetime
        try:
            date_obj = datetime.strptime(log_date, '%Y-%m-%d').date()
        except:
            return JsonResponse({'code': 400, 'msg': '日期格式错误'})

        # 检查是否已存在
        log = ConstructionLog.objects.filter(project_name=project, log_date=log_date, is_deleted=False).first()
        if log:
            return JsonResponse({'code': 0, 'msg': '该日期日志已存在', 'data': {'id': log.id, 'exists': True}})

        # 创建补录日志
        log = ConstructionLog.objects.create(
            project_name=project,
            log_date=log_date,
            construction_unit='中国石油天然气管道第二工程有限公司',
            weather_location=city_code,
            creator_openid=user['openid'],
            creator_name=user['name']
        )

        return JsonResponse({
            'code': 0,
            'msg': '补录日志创建成功',
            'data': {
                'id': log.id,
                'projectName': log.project_name,
                'logDate': str(log.log_date),
                'exists': False
            }
        })
    except Exception as e:
        return JsonResponse({'code': 500, 'msg': str(e)})

@safe_db_query
@csrf_exempt
def api_admin_login(request):
    '''管理员登录验证'''
    if request.method != 'POST':
        return JsonResponse({'code': 405, 'msg': '仅支持POST'})
    try:
        payload = _get_json_body(request)
        account = payload.get('account', '').strip()
        password = payload.get('password', '').strip()
        if account != 'admin' or password != 'cqytxm':
            return JsonResponse({'code': 401, 'msg': '账号或密码错误'})
        # 创建或更新管理员用户
        openid = 'admin_' + str(int(__import__('time').time()))
        user, _ = WeChatUser.objects.get_or_create(openid=openid, defaults={'name': '管理员', 'is_admin': True})
        user.is_admin = True
        user.save()
        # 设置 session
        request.session['wx_openid'] = openid
        request.session['wx_name'] = '管理员'
        request.session.modified = True
        return JsonResponse({'code': 0, 'msg': '登录成功', 'data': {'openid': openid, 'name': '管理员', 'is_admin': True}})
    except Exception as e:
        return JsonResponse({'code': 500, 'msg': str(e)})

# ========== 数据安全保障: 监控与审计接口 ==========

@safe_db_query
@require_http_methods(["GET"])
def api_health_check(request):
    """系统健康检查: 数据库连接、磁盘空间、审计统计"""
    import shutil
    from django.db import connection

    status = {"status": "ok", "checks": {}}
    code = 200

    # 数据库检查
    try:
        with connection.cursor() as cursor:
            cursor.execute("SELECT 1")
            status["checks"]["database"] = "connected"
    except Exception as e:
        status["checks"]["database"] = f"error: {str(e)}"
        status["status"] = "error"
        code = 503

    # 磁盘空间检查
    try:
        stat = shutil.disk_usage("/app")
        free_gb = stat.free / (1024**3)
        status["checks"]["disk_free_gb"] = round(free_gb, 2)
        if free_gb < 1:
            status["checks"]["disk"] = "warning: 磁盘空间不足1GB"
            status["status"] = "warning"
    except Exception as e:
        status["checks"]["disk"] = f"error: {str(e)}"

    # 审计日志表统计
    try:
        log_count = OperationLog.objects.count()
        today_count = OperationLog.objects.filter(created_at__date=datetime.now().date()).count()
        status["checks"]["audit_logs_total"] = log_count
        status["checks"]["audit_logs_today"] = today_count
    except Exception as e:
        status["checks"]["audit_logs"] = f"error: {str(e)}"

    return JsonResponse(status, status=code)


@safe_db_query
@csrf_exempt
@require_http_methods(["GET"])
def api_audit_logs(request):
    """查询操作审计日志(仅管理员)"""
    try:
        user = get_current_user(request)
        if not user["is_admin"]:
            return JsonResponse({"code": 403, "msg": "仅管理员可查看审计日志"})

        action = request.GET.get("action", "")
        project = request.GET.get("project", "")
        date_from = request.GET.get("date_from", "")
        date_to = request.GET.get("date_to", "")
        limit = int(request.GET.get("limit", "100"))

        qs = OperationLog.objects.all()
        if action:
            qs = qs.filter(action=action)
        if project:
            qs = qs.filter(project_name__icontains=project)
        if date_from:
            qs = qs.filter(created_at__date__gte=date_from)
        if date_to:
            qs = qs.filter(created_at__date__lte=date_to)

        qs = qs.order_by("-created_at")[:limit]
        data = [{
            "id": o.id,
            "action": o.get_action_display(),
            "actionCode": o.action,
            "userName": o.user_name,
            "userOpenid": o.user_openid[:16] + "..." if o.user_openid else "",
            "projectName": o.project_name,
            "logDate": str(o.log_date) if o.log_date else "",
            "logId": o.log_id,
            "detail": o.detail,
            "ip": str(o.ip_address) if o.ip_address else "",
            "entryType": o.entry_type,
            "createdAt": o.created_at.strftime("%Y-%m-%d %H:%M:%S"),
        } for o in qs]

        return JsonResponse({"code": 0, "data": data, "count": len(data)})
    except Exception as e:
        return JsonResponse({"code": 500, "msg": str(e)})


@safe_db_query
@csrf_exempt
@require_http_methods(["POST"])
def api_batch_restore(request):
    """批量恢复回收站日志"""
    try:
        entry_type = request.GET.get("entry", "")
        if entry_type == "user":
            return JsonResponse({"code": 403, "msg": "用户入口无权恢复"})

        user = get_current_user(request)
        if not user["is_admin"]:
            return JsonResponse({"code": 403, "msg": "仅管理员可批量恢复"})

        payload = _get_json_body(request)
        ids = payload.get("ids", [])
        if not ids:
            return JsonResponse({"code": 400, "msg": "请提供要恢复的日志ID列表"})

        restored = 0
        with transaction.atomic():
            for pk in ids:
                try:
                    log = ConstructionLog.objects.get(pk=pk, is_deleted=True)
                    log.is_deleted = False
                    log.deleted_at = None
                    log.deleted_by = ""
                    log.save()
                    log_operation(request, "RESTORE", log.project_name, log.log_date, log.id,
                                  f"批量恢复 操作人:{user.get('name','')}")
                    restored += 1
                except ConstructionLog.DoesNotExist:
                    pass

        return JsonResponse({"code": 0, "msg": f"成功恢复 {restored} 条日志"})
    except Exception as e:
        return JsonResponse({"code": 500, "msg": str(e)})

# ========== 版本历史与回滚接口 ==========

@safe_db_query
@csrf_exempt
@require_http_methods(["GET"])
def api_log_versions(request, pk):
    """查询某条日志的历史版本。所有人员均可查看最近5条版本记录"""
    try:
        user = get_current_user(request)
        log = get_object_or_404(ConstructionLog, pk=pk, is_deleted=False)

        # 所有人员均可查看版本历史，限最近5条
        versions = LogVersion.objects.filter(log=log).order_by("-version_no")[:5]

        data = [{
            "versionNo": v.version_no,
            "editorName": v.editor_name,
            "editorOpenid": v.editor_openid[:16] + "..." if v.editor_openid else "",
            "changeSummary": v.change_summary,
            "ipAddress": str(v.ip_address) if v.ip_address else "",
            "createdAt": v.created_at.strftime("%Y-%m-%d %H:%M:%S"),
            "recorder": v.recorder,
            "recordDate": str(v.record_date) if v.record_date else "",
        } for v in versions]

        total_all = LogVersion.objects.filter(log=log).count()

        return JsonResponse({
            "code": 0,
            "data": data,
            "currentVersion": versions.first().version_no if versions.exists() else 0,
            "totalVersions": len(data),
            "totalAllVersions": total_all,
            "logId": log.id,
            "projectName": log.project_name,
            "logDate": str(log.log_date),
            "isAdmin": user["is_admin"],
            "maxVersionsForUser": 5,
        })
    except Exception as e:
        return JsonResponse({"code": 500, "msg": str(e)})


@safe_db_query
@csrf_exempt
@require_http_methods(["POST"])
def api_log_rollback(request, pk):
    """回滚到指定历史版本。所有人员均可回滚最近5个版本"""
    try:
        user = get_current_user(request)
        log = get_object_or_404(ConstructionLog, pk=pk, is_deleted=False)

        # 所有人员均可回滚，限最近5个版本
        payload = _get_json_body(request)
        version_no = payload.get("versionNo")
        if not version_no:
            return JsonResponse({"code": 400, "msg": "请提供要回滚的版本号"})

        target = get_object_or_404(LogVersion, log=log, version_no=version_no)

        # 所有人员只能回滚最近5个版本
        recent_versions = LogVersion.objects.filter(log=log).order_by("-version_no")[:5]
        recent_version_nos = [v.version_no for v in recent_versions]
        if int(version_no) not in recent_version_nos:
            return JsonResponse({"code": 403, "msg": "只能回滚最近的5个版本，该版本已超出范围"})

        # 回滚前先对当前状态创建快照（便于二次回滚）
        snapshot_data = {
            'project_name': log.project_name,
            'log_date': log.log_date,
            'construction_unit': log.construction_unit,
            'weather_location': log.weather_location,
            'weather_day': log.weather_day,
            'weather_night': log.weather_night,
            'wind_level': log.wind_level,
            'temp_high': log.temp_high,
            'temp_low': log.temp_low,
            'weather_remark': log.weather_remark,
            'special_situation': log.special_situation,
            'study_prepare': log.study_prepare,
            'progress': log.progress,
            'machinery': log.machinery,
            'in_out': log.in_out,
            'other_problems': log.other_problems,
            'scheme_review': log.scheme_review,
            'design_review': log.design_review,
            'contact_sheet': log.contact_sheet,
            'material_test': log.material_test,
            'quality_check': log.quality_check,
            'hidden_check': log.hidden_check,
            'acceptance': log.acceptance,
            'inspection': log.inspection,
            'meeting': log.meeting,
            'quality_safety': log.quality_safety,
            'special_method': log.special_method,
            'visa': log.visa,
            'activities': log.activities,
            'accident': log.accident,
            'recorder': log.recorder,
            'record_date': log.record_date,
        }
        current_version = create_version_snapshot(
            log, snapshot_data, user,
            change_summary=f"回滚前自动备份: 准备回滚到v{version_no}",
            ip=get_client_ip(request)
        )

        with transaction.atomic():
            # 将目标版本的数据覆盖回主表
            log.project_name = target.project_name
            log.log_date = target.log_date
            log.construction_unit = target.construction_unit
            log.weather_location = target.weather_location
            log.weather_day = target.weather_day
            log.weather_night = target.weather_night
            log.wind_level = target.wind_level
            log.temp_high = target.temp_high
            log.temp_low = target.temp_low
            log.weather_remark = target.weather_remark
            log.special_situation = target.special_situation
            log.study_prepare = target.study_prepare
            log.progress = target.progress
            log.machinery = target.machinery
            log.in_out = target.in_out
            log.other_problems = target.other_problems
            log.scheme_review = target.scheme_review
            log.design_review = target.design_review
            log.contact_sheet = target.contact_sheet
            log.material_test = target.material_test
            log.quality_check = target.quality_check
            log.hidden_check = target.hidden_check
            log.acceptance = target.acceptance
            log.inspection = target.inspection
            log.meeting = target.meeting
            log.quality_safety = target.quality_safety
            log.special_method = target.special_method
            log.visa = target.visa
            log.activities = target.activities
            log.accident = target.accident
            log.recorder = target.recorder
            log.record_date = target.record_date
            log.save()

        # 记录审计日志
        log_operation(
            request, "ROLLBACK", log.project_name, log.log_date, log.id,
            f"回滚到v{version_no} 操作人:{user.get('name','')} 备份版本:v{current_version}"
        )

        return JsonResponse({
            "code": 0,
            "msg": f"已成功回滚到版本 v{version_no}",
            "data": {
                "rollbackToVersion": version_no,
                "backupVersion": current_version,
                "projectName": log.project_name,
                "logDate": str(log.log_date),
            }
        })
    except Exception as e:
        return JsonResponse({"code": 500, "msg": str(e)})
