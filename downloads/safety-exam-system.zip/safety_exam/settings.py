"""
Django settings for safety_exam project.
独立部署的在线安全培训考试系统
优化版：兼容微信云托管环境变量命名（MYSQL_* / DJANGO_SECRET_KEY）
"""
import os
from pathlib import Path
import pymysql
pymysql.install_as_MySQLdb()

BASE_DIR = Path(__file__).resolve().parent.parent

# =================== 环境变量兼容配置 ===================
# 优先读取安全考试系统命名，fallback 到施工日志系统命名
SECRET_KEY = os.environ.get('SECRET_KEY')     or os.environ.get('DJANGO_SECRET_KEY')     or 'django-insecure-change-me-in-production'

DEBUG = os.environ.get('DEBUG', 'False').lower() == 'true'

ALLOWED_HOSTS = ['*']

INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'corsheaders',
    'exam',
]

MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'whitenoise.middleware.WhiteNoiseMiddleware',
    'corsheaders.middleware.CorsMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    # 注意：API 接口单独使用 @csrf_exempt，模板表单保留 CSRF 保护
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'safety_exam.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [BASE_DIR / 'templates'],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

WSGI_APPLICATION = 'safety_exam.wsgi.application'

# =================== 数据库配置 ===================
# 兼容两种环境变量命名方式
DB_NAME = os.environ.get('DB_NAME') or os.environ.get('MYSQL_DATABASE') or 'safety_exam'
DB_USER = os.environ.get('DB_USER') or os.environ.get('MYSQL_USER') or 'root'
DB_PASSWORD = os.environ.get('DB_PASSWORD') or os.environ.get('MYSQL_PASSWORD') or ''
DB_HOST = os.environ.get('DB_HOST') or os.environ.get('MYSQL_HOST') or 'localhost'
DB_PORT = os.environ.get('DB_PORT') or os.environ.get('MYSQL_PORT') or '3306'

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': DB_NAME,
        'USER': DB_USER,
        'PASSWORD': DB_PASSWORD,
        'HOST': DB_HOST,
        'PORT': DB_PORT,
        'OPTIONS': {
            'charset': 'utf8mb4',
            'init_command': "SET sql_mode='STRICT_TRANS_TABLES'",
        },
    }
}

# 如果云托管未提供 MySQL，可回退到 SQLite（仅开发测试）
if os.environ.get('USE_SQLITE') == 'true':
    DATABASES['default'] = {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'db.sqlite3',
    }

LANGUAGE_CODE = 'zh-hans'
TIME_ZONE = 'Asia/Shanghai'
USE_I18N = True
USE_L10N = True
USE_TZ = True

STATIC_URL = '/static/'
STATIC_ROOT = BASE_DIR / 'staticfiles'
STATICFILES_STORAGE = 'whitenoise.storage.CompressedManifestStaticFilesStorage'

MEDIA_URL = '/media/'
MEDIA_ROOT = BASE_DIR / 'media'

DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'

# =================== 微信配置 ===================
WECHAT_APPID = os.environ.get('WECHAT_APPID', '')
WECHAT_SECRET = os.environ.get('WECHAT_SECRET', '')

# =================== CORS 配置 ===================
CORS_ALLOW_ALL_ORIGINS = True
CORS_ALLOW_CREDENTIALS = True

# =================== 会话配置 ===================
SESSION_ENGINE = 'django.contrib.sessions.backends.db'
SESSION_COOKIE_AGE = 3600  # 1小时
SESSION_COOKIE_HTTPONLY = True

# =================== CSRF & 安全 ===================
# 微信云托管内网通信优化
CSRF_TRUSTED_ORIGINS = [
    'https://*.sh.run.tcloudbase.com',
    'https://*.tcloudbase.com',
    'http://localhost:8000',
    'http://127.0.0.1:8000',
]
USE_X_FORWARDED_HOST = True
SECURE_PROXY_SSL_HEADER = ('HTTP_X_FORWARDED_PROTO', 'https')

# 开发环境关闭 HTTPS 强制
SECURE_SSL_REDIRECT = False
SESSION_COOKIE_SECURE = False
CSRF_COOKIE_SECURE = False

# =================== 日志配置 ===================
LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'handlers': {
        'console': {
            'class': 'logging.StreamHandler',
        },
    },
    'root': {
        'handlers': ['console'],
        'level': 'INFO',
    },
    'loggers': {
        'django': {
            'handlers': ['console'],
            'level': 'INFO',
            'propagate': False,
        },
        'exam': {
            'handlers': ['console'],
            'level': 'INFO',
            'propagate': False,
        },
    },
}
