from django.urls import path
from django.views.decorators.csrf import csrf_exempt
from . import views

urlpatterns = [
    path('', views.exam_list, name='exam_list'),
    path('login/', views.login_page, name='login_page'),
    path('manual-login/', csrf_exempt(views.manual_login), name='manual_login'),
    path('logout/', views.logout_view, name='logout'),
    path('wechat/callback/', views.wechat_callback, name='wechat_callback'),
    path('exam/<int:exam_id>/', views.take_exam, name='take_exam'),
    path('api/submit/', csrf_exempt(views.submit_exam), name='submit_exam'),
    path('result/<int:record_id>/', views.exam_result, name='exam_result'),
    path('pdf/<int:record_id>/', views.download_pdf, name='download_pdf'),
    path('init-demo/', csrf_exempt(views.init_demo_data), name='init_demo'),
    path('health/', views.health_check, name='health_check'),
    path('import-exam/', views.import_exam, name='import_exam'),
    path('download-template/', views.download_template, name='download_template'),
    path('generate-exam/', views.generate_exam, name='generate_exam'),
    path('auto-generate/', csrf_exempt(views.auto_generate_exam), name='auto_generate_exam'),
    # 管理员功能
    path('admin-login/', views.admin_login_page, name='admin_login_page'),
    path('admin-login-api/', csrf_exempt(views.admin_login), name='admin_login'),
    path('admin-logout/', views.admin_logout, name='admin_logout'),
    path('dashboard/', views.admin_dashboard, name='admin_dashboard'),
    path('dashboard/exam/<int:exam_id>/delete/', csrf_exempt(views.admin_delete_exam), name='admin_delete_exam'),
    path('dashboard/exam/<int:exam_id>/records/', views.admin_exam_records, name='admin_exam_records'),
    path('dashboard/exam/<int:exam_id>/export/', views.admin_export_records, name='admin_export_records'),
    path('dashboard/all-records/', views.admin_all_records, name='admin_all_records'),
    path('dashboard/record/<int:record_id>/', views.admin_view_record, name='admin_view_record'),
    path('dashboard/export-all-pdf/', csrf_exempt(views.admin_export_all_pdf), name='admin_export_all_pdf'),
    # 考生功能
    path('my-records/', views.my_records, name='my_records'),
]
