from django.apps import AppConfig

class ExamConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'exam'
    verbose_name = '安全培训考试'
