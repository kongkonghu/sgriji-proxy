import json
from django.db import models

class Exam(models.Model):
    title = models.CharField(max_length=200, verbose_name='考试名称')
    description = models.TextField(blank=True, verbose_name='考试说明')
    time_limit = models.PositiveIntegerField(default=30, verbose_name='考试时长(分钟)')
    pass_score = models.PositiveIntegerField(default=60, verbose_name='及格分数')
    total_score = models.PositiveIntegerField(default=100, verbose_name='满分分值')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = '考试'
        verbose_name_plural = '考试管理'

    def __str__(self):
        return self.title


class Question(models.Model):
    QTYPE_SINGLE = 'single'
    QTYPE_MULTI = 'multi'
    QTYPE_JUDGE = 'judge'
    QTYPE_FILL = 'fill'
    QTYPE_ESSAY = 'essay'

    QTYPE_CHOICES = [
        (QTYPE_SINGLE, '单选题'),
        (QTYPE_MULTI, '多选题'),
        (QTYPE_JUDGE, '判断题'),
        (QTYPE_FILL, '填空题'),
        (QTYPE_ESSAY, '问答题'),
    ]

    exam = models.ForeignKey(Exam, on_delete=models.CASCADE, related_name='questions', verbose_name='所属考试')
    q_type = models.CharField(max_length=20, choices=QTYPE_CHOICES, default=QTYPE_SINGLE, verbose_name='题型')
    content = models.TextField(verbose_name='题干')
    options = models.JSONField(default=dict, blank=True, verbose_name='选项')
    correct_answer = models.CharField(max_length=200, verbose_name='正确答案')
    score = models.PositiveIntegerField(default=5, verbose_name='分值')
    order = models.PositiveIntegerField(default=0, verbose_name='排序')
    tag = models.CharField(max_length=100, blank=True, verbose_name='标签')
    analysis = models.TextField(blank=True, verbose_name='答案解析')

    class Meta:
        ordering = ['order', 'id']
        verbose_name = '题目'
        verbose_name_plural = '题目管理'

    def __str__(self):
        return f"[{self.get_q_type_display()}] {self.content[:30]}"

    def get_correct_list(self):
        if self.q_type == self.QTYPE_MULTI:
            return sorted(self.correct_answer.replace('|', ',').split(','))
        return [self.correct_answer]


class QuestionBank(models.Model):
    QTYPE_CHOICES = Question.QTYPE_CHOICES

    q_type = models.CharField(max_length=20, choices=QTYPE_CHOICES, default='single', verbose_name='题型')
    content = models.TextField(verbose_name='题干')
    options = models.JSONField(default=dict, blank=True, verbose_name='选项')
    correct_answer = models.CharField(max_length=200, verbose_name='正确答案')
    tag = models.CharField(max_length=100, blank=True, verbose_name='标签/岗位')
    analysis = models.TextField(blank=True, verbose_name='答案解析')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = '题库题目'
        verbose_name_plural = '题库管理'
        ordering = ['-created_at']

    def __str__(self):
        return f"[{self.get_q_type_display()}] {self.content[:30]}"


class ExamRecord(models.Model):
    exam = models.ForeignKey(Exam, on_delete=models.CASCADE, related_name='records', verbose_name='考试')
    user_name = models.CharField(max_length=100, verbose_name='考生姓名')
    user_openid = models.CharField(max_length=100, blank=True, verbose_name='OpenID')
    user_phone = models.CharField(max_length=20, blank=True, verbose_name='手机号')
    score = models.PositiveIntegerField(default=0, verbose_name='得分')
    is_pass = models.BooleanField(default=False, verbose_name='是否及格')
    signature = models.ImageField(upload_to='signatures/', blank=True, null=True, verbose_name='电子签名')
    attempt_number = models.PositiveIntegerField(default=1, verbose_name='考试次数')
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = '考试记录'
        verbose_name_plural = '考试记录'

    def __str__(self):
        return f"{self.user_name} - {self.exam.title} - {self.score}分"


class Answer(models.Model):
    record = models.ForeignKey(ExamRecord, on_delete=models.CASCADE, related_name='answers', verbose_name='考试记录')
    question = models.ForeignKey(Question, on_delete=models.CASCADE, verbose_name='题目')
    user_answer = models.CharField(max_length=200, blank=True, verbose_name='考生答案')
    is_correct = models.BooleanField(default=False, verbose_name='是否正确')

    class Meta:
        verbose_name = '答题记录'
        verbose_name_plural = '答题记录'
