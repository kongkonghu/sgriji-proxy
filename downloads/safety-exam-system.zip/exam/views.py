import os
import json
import base64
import csv
import io
import requests
from datetime import datetime

from django.shortcuts import render, redirect, get_object_or_404
from django.http import JsonResponse, HttpResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST
from django.conf import settings
from django.utils import timezone
from django.db import connection
from django.db.models import Count, Max

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, Image
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.enums import TA_CENTER, TA_LEFT

try:
    import openpyxl
    HAS_OPENPYXL = True
except ImportError:
    HAS_OPENPYXL = False

from .models import Exam, Question, ExamRecord, Answer, QuestionBank


# =================== 微信登录相关 ===================

def wechat_login_url(request):
    appid = settings.WECHAT_APPID
    if not appid:
        return None
    redirect_uri = request.build_absolute_uri('/wechat/callback/')
    scope = 'snsapi_userinfo'
    state = request.GET.get('next', '/')
    url = (f"https://open.weixin.qq.com/connect/oauth2/authorize?"
           f"appid={appid}&redirect_uri={redirect_uri}"
           f"&response_type=code&scope={scope}&state={state}#wechat_redirect")
    return url


def wechat_callback(request):
    code = request.GET.get('code')
    state = request.GET.get('state', '/')
    if not code:
        return render(request, 'exam/error.html', {'msg': '微信授权失败，未获取到 code'})
    if not settings.WECHAT_APPID or not settings.WECHAT_SECRET:
        return render(request, 'exam/error.html', {'msg': '系统未配置微信登录参数'})

    token_url = (f"https://api.weixin.qq.com/sns/oauth2/access_token?"
                 f"appid={settings.WECHAT_APPID}&secret={settings.WECHAT_SECRET}"
                 f"&code={code}&grant_type=authorization_code")
    try:
        resp = requests.get(token_url, timeout=10)
        data = resp.json()
    except Exception as e:
        return render(request, 'exam/error.html', {'msg': f'微信接口请求失败: {str(e)}'})

    if 'openid' not in data:
        return render(request, 'exam/error.html', {'msg': f"微信接口错误: {data}"})

    openid = data['openid']
    access_token = data['access_token']

    user_url = (f"https://api.weixin.qq.com/sns/userinfo?"
                f"access_token={access_token}&openid={openid}&lang=zh_CN")
    try:
        user_resp = requests.get(user_url, timeout=10)
        user_info = user_resp.json()
    except Exception as e:
        user_info = {}

    request.session['user_openid'] = openid
    request.session['user_name'] = user_info.get('nickname', '微信用户')
    request.session['user_avatar'] = user_info.get('headimgurl', '')
    request.session['login_type'] = 'wechat'
    return redirect(state)


def login_page(request):
    if request.session.get('user_name'):
        return redirect('exam_list')
    ua = request.META.get('HTTP_USER_AGENT', '').lower()
    is_wechat = 'micromessenger' in ua
    if is_wechat and settings.WECHAT_APPID and settings.WECHAT_SECRET:
        wx_url = wechat_login_url(request)
        if wx_url:
            return redirect(wx_url)
    return render(request, 'exam/login.html')


@csrf_exempt
@require_POST
def manual_login(request):
    if request.content_type and 'application/json' in request.content_type:
        try:
            data = json.loads(request.body)
        except json.JSONDecodeError:
            return JsonResponse({'status': 'error', 'msg': 'JSON 格式错误'})
        name = data.get('name', '').strip()
        phone = data.get('phone', '').strip()
    else:
        name = request.POST.get('name', '').strip()
        phone = request.POST.get('phone', '').strip()

    if not name:
        return JsonResponse({'status': 'error', 'msg': '请输入姓名'})

    request.session['user_name'] = name
    request.session['user_phone'] = phone
    request.session['user_openid'] = ''
    request.session['login_type'] = 'manual'
    return JsonResponse({'status': 'ok', 'redirect': '/'})


def logout_view(request):
    request.session.flush()
    return redirect('login_page')


# =================== 考试业务逻辑 ===================

def exam_list(request):
    if not request.session.get('user_name'):
        return redirect('login_page')

    exams = Exam.objects.annotate(question_count=Count('questions')).all()
    user_openid = request.session.get('user_openid', '')
    user_name = request.session.get('user_name', '')

    for exam in exams:
        # 查询该用户最新的考试记录
        filters = {'exam': exam}
        if user_openid:
            filters['user_openid'] = user_openid
        else:
            filters['user_name'] = user_name

        latest_record = ExamRecord.objects.filter(**filters).order_by('-created_at').first()
        if latest_record:
            exam.has_taken = True
            exam.latest_record = latest_record
            exam.attempt_count = ExamRecord.objects.filter(**filters).count()
        else:
            exam.has_taken = False
            exam.latest_record = None
            exam.attempt_count = 0

    return render(request, 'exam/exam_list.html', {
        'exams': exams,
        'user_name': request.session.get('user_name'),
    })


def take_exam(request, exam_id):
    if not request.session.get('user_name'):
        return redirect('login_page')

    exam = get_object_or_404(Exam, id=exam_id)
    questions = exam.questions.all().order_by('order')

    user_openid = request.session.get('user_openid', '')
    user_name = request.session.get('user_name', '')

    # 计算本次考试次数
    filters = {'exam': exam}
    if user_openid:
        filters['user_openid'] = user_openid
    else:
        filters['user_name'] = user_name

    attempt_count = ExamRecord.objects.filter(**filters).count()

    # 创建新的考试记录（允许多次考试）
    record = ExamRecord.objects.create(
        exam=exam,
        user_name=user_name,
        user_openid=user_openid,
        user_phone=request.session.get('user_phone', ''),
        attempt_number=attempt_count + 1,
    )

    request.session['current_record_id'] = record.id

    return render(request, 'exam/take_exam.html', {
        'exam': exam,
        'questions': questions,
        'record_id': record.id,
        'time_limit': exam.time_limit,
    })


@csrf_exempt
@require_POST
def submit_exam(request):
    try:
        data = json.loads(request.body)
    except json.JSONDecodeError:
        return JsonResponse({'status': 'error', 'msg': '数据格式错误'})

    record_id = data.get('record_id')
    answers_data = data.get('answers', {})
    signature_data = data.get('signature', '')

    if not record_id:
        return JsonResponse({'status': 'error', 'msg': '考试记录不存在'})

    record = get_object_or_404(ExamRecord, id=record_id)

    if signature_data:
        try:
            img_data = base64.b64decode(signature_data.split(',')[1])
            from django.core.files.base import ContentFile
            filename = f"sig_{record.id}_{datetime.now().strftime('%Y%m%d%H%M%S')}.png"
            record.signature.save(filename, ContentFile(img_data), save=True)
        except Exception as e:
            print(f"签名保存失败: {e}")

    total_score = 0
    for qid, user_ans in answers_data.items():
        try:
            question = Question.objects.get(id=int(qid))
        except (Question.DoesNotExist, ValueError):
            continue

        if isinstance(user_ans, list):
            user_ans_str = ','.join(sorted(user_ans))
        else:
            user_ans_str = str(user_ans).strip()

        correct = question.get_correct_list()
        user_sorted = sorted(user_ans_str.split(',')) if user_ans_str else []
        is_correct = (correct == user_sorted)
        if is_correct:
            total_score += question.score

        Answer.objects.create(
            record=record,
            question=question,
            user_answer=user_ans_str,
            is_correct=is_correct,
        )

    record.score = total_score
    record.is_pass = total_score >= record.exam.pass_score
    record.save()

    if request.session.get('current_record_id') == record.id:
        del request.session['current_record_id']

    return JsonResponse({
        'status': 'ok',
        'record_id': record.id,
        'score': total_score,
        'is_pass': record.is_pass,
        'pass_score': record.exam.pass_score,
    })


def exam_result(request, record_id):
    if not request.session.get('user_name'):
        return redirect('login_page')

    record = get_object_or_404(ExamRecord, id=record_id)
    answers = record.answers.select_related('question').all()

    return render(request, 'exam/result.html', {
        'record': record,
        'answers': answers,
        'user_name': request.session.get('user_name'),
    })


# =================== PDF 下载 ===================

def download_pdf(request, record_id):
    record = get_object_or_404(ExamRecord, id=record_id)
    answers = record.answers.select_related('question').all().order_by('question__order')

    font_paths = [
        '/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc',
        '/usr/share/fonts/truetype/wqy/wqy-microhei.ttc',
        '/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc',
        '/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc',
        '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',
    ]

    font_name = 'Helvetica'
    for fp in font_paths:
        if os.path.exists(fp):
            try:
                if 'wqy' in fp or 'Noto' in fp or 'CJK' in fp:
                    pdfmetrics.registerFont(TTFont('ChineseFont', fp, subfontIndex=0))
                    font_name = 'ChineseFont'
                else:
                    pdfmetrics.registerFont(TTFont('CustomFont', fp))
                    font_name = 'CustomFont'
                break
            except Exception as e:
                print(f"字体注册失败 {fp}: {e}")
                continue

    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(
        name='Chinese', fontName=font_name, fontSize=12, leading=20, alignment=TA_LEFT,
    ))
    styles.add(ParagraphStyle(
        name='ChineseCenter', fontName=font_name, fontSize=14, leading=24,
        alignment=TA_CENTER, spaceAfter=12,
    ))
    styles.add(ParagraphStyle(
        name='ChineseSmall', fontName=font_name, fontSize=10, leading=16, alignment=TA_LEFT,
    ))

    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4, rightMargin=2*cm, leftMargin=2*cm,
                            topMargin=2*cm, bottomMargin=2*cm)

    story = []
    story.append(Paragraph(f"{record.exam.title} - 考试报告", styles['ChineseCenter']))
    story.append(Spacer(1, 0.5*cm))

    info_data = [
        ['考生姓名', record.user_name or '未填写'],
        ['手机号码', record.user_phone or '未填写'],
        ['考试时间', record.created_at.strftime('%Y-%m-%d %H:%M')],
        ['考试得分', f"{record.score} 分 / {record.exam.total_score} 分"],
        ['是否及格', '及格' if record.is_pass else '不及格'],
        ['及格线', f"{record.exam.pass_score} 分"],
        ['考试次数', f"第 {record.attempt_number} 次"],
    ]
    info_table = Table(info_data, colWidths=[4*cm, 10*cm])
    info_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (0, -1), colors.lightgrey),
        ('TEXTCOLOR', (0, 0), (-1, -1), colors.black),
        ('ALIGN', (0, 0), (0, -1), 'CENTER'),
        ('ALIGN', (1, 0), (1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (-1, -1), font_name),
        ('FONTSIZE', (0, 0), (-1, -1), 11),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('TOPPADDING', (0, 0), (-1, -1), 6),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
    ]))
    story.append(info_table)
    story.append(Spacer(1, 0.8*cm))

    if record.signature:
        story.append(Paragraph("考生电子签名：", styles['Chinese']))
        story.append(Spacer(1, 0.3*cm))
        try:
            img_path = record.signature.path
            if os.path.exists(img_path):
                img = Image(img_path, width=6*cm, height=2*cm)
                story.append(img)
        except Exception as e:
            story.append(Paragraph(f"[签名图片加载失败: {str(e)}]", styles['ChineseSmall']))
        story.append(Spacer(1, 0.5*cm))

    story.append(Paragraph("答题详情：", styles['Chinese']))
    story.append(Spacer(1, 0.3*cm))

    for idx, ans in enumerate(answers, 1):
        q = ans.question
        q_text = f"{idx}. [{q.get_q_type_display()}] {q.content}"
        story.append(Paragraph(q_text, styles['Chinese']))

        if q.options:
            for k, v in q.options.items():
                story.append(Paragraph(f"&nbsp;&nbsp;&nbsp;&nbsp;{k}. {v}", styles['ChineseSmall']))

        status_color = colors.green if ans.is_correct else colors.red
        status_text = "✓ 正确" if ans.is_correct else "✗ 错误"
        story.append(Paragraph(
            f"<font color={status_color.hexval()}>{status_text}</font> "
            f"你的答案: {ans.user_answer or '未作答'} | "
            f"正确答案: {q.correct_answer}",
            styles['ChineseSmall']
        ))
        story.append(Spacer(1, 0.3*cm))

    story.append(Spacer(1, 1*cm))
    story.append(Paragraph(
        f"本报告由在线安全培训考试系统自动生成 | 生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        styles['ChineseSmall']
    ))

    doc.build(story)
    pdf = buffer.getvalue()
    buffer.close()

    response = HttpResponse(pdf, content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="exam_report_{record.id}.pdf"'
    return response


# =================== 管理员后台 ===================



# =================== 管理员认证 ===================

ADMIN_USERNAME = 'admin'
ADMIN_PASSWORD = 'cqytxm'

def admin_login_page(request):
    """管理员登录页面"""
    if request.session.get('is_admin'):
        return redirect('admin_dashboard')
    return render(request, 'exam/admin_login.html')


@csrf_exempt
@require_POST
def admin_login(request):
    """管理员登录验证"""
    username = request.POST.get('username', '').strip()
    password = request.POST.get('password', '').strip()

    if username == ADMIN_USERNAME and password == ADMIN_PASSWORD:
        request.session['is_admin'] = True
        request.session['admin_name'] = username
        return JsonResponse({'status': 'ok', 'redirect': '/dashboard/'})
    else:
        return JsonResponse({'status': 'error', 'msg': '用户名或密码错误'})


def admin_logout(request):
    """管理员退出"""
    request.session.pop('is_admin', None)
    request.session.pop('admin_name', None)
    return redirect('admin_login_page')


def check_admin(request):
    """检查是否是管理员"""
    if not request.session.get('is_admin'):
        return False
    return True

def admin_dashboard(request):
    """管理员仪表盘"""
    if not check_admin(request):
        return redirect('admin_login_page')

    user_name = request.session.get('admin_name', '管理员')

    stats = {
        'exam_count': Exam.objects.count(),
        'question_count': Question.objects.count(),
        'bank_count': QuestionBank.objects.count(),
        'record_count': ExamRecord.objects.count(),
        'user_count': ExamRecord.objects.values('user_name').distinct().count(),
    }

    exams = Exam.objects.annotate(question_count=Count('questions'), record_count=Count('records')).all()

    return render(request, 'exam/admin_dashboard.html', {
        'stats': stats,
        'exams': exams,
        'user_name': user_name,
    })


@csrf_exempt
def admin_delete_exam(request, exam_id):
    """删除考试"""
    if request.method != 'POST':
        return JsonResponse({'status': 'error', 'msg': '仅支持 POST'})

    if not check_admin(request):
        return JsonResponse({'status': 'error', 'msg': '无权限'})

    exam = get_object_or_404(Exam, id=exam_id)
    exam.delete()
    return JsonResponse({'status': 'ok', 'msg': '考试已删除'})


def admin_exam_records(request, exam_id):
    """查看某考试的所有成绩"""
    if not check_admin(request):
        return redirect('admin_login_page')

    user_name = request.session.get('admin_name', '管理员')

    exam = get_object_or_404(Exam, id=exam_id)
    records = exam.records.all().order_by('-created_at')

    return render(request, 'exam/admin_records.html', {
        'exam': exam,
        'records': records,
    })


def admin_export_records(request, exam_id):
    """导出考试成绩为 CSV"""
    if not check_admin(request):
        return redirect('admin_login_page')

    user_name = request.session.get('admin_name', '管理员')

    exam = get_object_or_404(Exam, id=exam_id)
    records = exam.records.all().order_by('-created_at')

    response = HttpResponse(content_type='text/csv; charset=utf-8-sig')
    response['Content-Disposition'] = f'attachment; filename="{exam.title}_成绩.csv"'

    writer = csv.writer(response)
    writer.writerow(['序号', '姓名', '手机号', '得分', '满分', '是否及格', '考试次数', '考试时间'])

    for idx, record in enumerate(records, 1):
        writer.writerow([
            idx,
            record.user_name,
            record.user_phone,
            record.score,
            exam.total_score,
            '及格' if record.is_pass else '不及格',
            f"第{record.attempt_number}次",
            record.created_at.strftime('%Y-%m-%d %H:%M'),
        ])

    return response


def my_records(request):
    """考生查看自己的所有考试记录"""
    if not request.session.get('user_name'):
        return redirect('login_page')

    user_openid = request.session.get('user_openid', '')
    user_name = request.session.get('user_name', '')

    filters = {}
    if user_openid:
        filters['user_openid'] = user_openid
    else:
        filters['user_name'] = user_name

    records = ExamRecord.objects.filter(**filters).select_related('exam').order_by('-created_at')

    return render(request, 'exam/my_records.html', {
        'records': records,
        'user_name': user_name,
    })


# =================== 题库管理与随机组卷 ===================

def download_template(request):
    """下载标准试卷导入模板（Excel格式）"""
    try:
        from openpyxl.styles import Font, Alignment, PatternFill, Border, Side

        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "试题模板"

        notice_lines = [
            "填写注意事项：",
            "1. 第1行和第2行不可修改或删除！",
            "2. 单选题/多选题：最多可添加10个选项（选项A~选项J）；多选题多个答案用|分隔（如A|B|C）。",
            "3. 判断题：只能设置两个选项，正确和错误。",
            "4. 填空题：题干填空处使用[]，答案按填空顺序填写，不同填空用顿号分隔。",
            "5. 问答题：答案为空。",
            "6. 标签：非必填，可根据岗位填写（如操作岗、管工、电焊工等）。",
            "7. 分数：导入试卷时必填，支持小数点后一位。",
            "8. 若填写后单元格显示红色底色表示填写有误，请参照样例检查。",
        ]
        notice = "\n".join(notice_lines)

        ws.merge_cells('A1:P1')
        ws['A1'] = notice
        ws['A1'].alignment = Alignment(wrap_text=True, vertical='top')
        ws['A1'].font = Font(size=10, color='FF0000')
        ws.row_dimensions[1].height = 120

        ws.merge_cells('A2:P2')
        ws['A2'] = notice
        ws.row_dimensions[2].height = 30

        headers = [
            '题型（必选）', '题干（必填）', '答案（必填）', '答案解析（选填）',
            '标签（仅导入题库时有效）', '分数（导入试卷时必填）',
            '选项A', '选项B', '选项C', '选项D', '选项E', '选项F',
            '选项G', '选项H', '选项I', '选项J'
        ]

        header_fill = PatternFill(start_color='E8F4FD', end_color='E8F4FD', fill_type='solid')
        header_font = Font(bold=True, size=11)
        thin_border = Border(
            left=Side(style='thin'), right=Side(style='thin'),
            top=Side(style='thin'), bottom=Side(style='thin')
        )

        for col_idx, header in enumerate(headers, 1):
            cell = ws.cell(row=3, column=col_idx, value=header)
            cell.fill = header_fill
            cell.font = header_font
            cell.border = thin_border
            cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)

        samples = [
            ['单选题', '进入施工现场必须佩戴的安全防护用品是？', 'A', '', '操作岗', '5',
             '安全帽', '手套', '护目镜', '安全鞋', '', '', '', '', '', ''],
            ['单选题', '高度在30米(含30米)以上称为（）高处作业。', 'D', '', '操作岗', '5',
             '四级', '三级', '二级', '特级', '', '', '', '', '', ''],
            ['多选题', '下列属于集团公司《反违章禁令》的是（）。', 'A|B|C|D', '', '操作岗', '5',
             '严禁特种作业无有效操作证人员上岗操作', '严禁违反操作规程操作',
             '严禁无票证从事危险作业', '严禁违章指挥、强令他人违章作业', '', '', '', '', '', ''],
            ['判断题', '施工作业前应进行安全交底。', 'A', '', '操作岗', '5',
             '正确', '错误', '', '', '', '', '', '', '', ''],
        ]

        for row_idx, row_data in enumerate(samples, 4):
            for col_idx, value in enumerate(row_data, 1):
                cell = ws.cell(row=row_idx, column=col_idx, value=value)
                cell.border = thin_border
                cell.alignment = Alignment(vertical='center', wrap_text=True)

        col_widths = [12, 50, 12, 20, 18, 14, 18, 18, 18, 18, 12, 12, 12, 12, 12, 12]
        for idx, width in enumerate(col_widths, 1):
            ws.column_dimensions[openpyxl.utils.get_column_letter(idx)].width = width

        buffer = io.BytesIO()
        wb.save(buffer)
        buffer.seek(0)

        response = HttpResponse(buffer.getvalue(),
                                content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
        response['Content-Disposition'] = 'attachment; filename="试题导入模板.xlsx"'
        return response

    except ImportError:
        response = HttpResponse(content_type='text/csv; charset=utf-8-sig')
        response['Content-Disposition'] = 'attachment; filename="试题导入模板.csv"'
        writer = csv.writer(response)
        writer.writerow(['题型（必选）', '题干（必填）', '答案（必填）', '答案解析（选填）',
                         '标签', '分数', '选项A', '选项B', '选项C', '选项D', '选项E',
                         '选项F', '选项G', '选项H', '选项I', '选项J'])
        writer.writerow(['单选题', '示例题目', 'A', '', '操作岗', '5',
                         '选项A', '选项B', '选项C', '选项D', '', '', '', '', '', ''])
        return response


@csrf_exempt
def import_exam(request):
    """批量导入题库 + 可选生成考试（管理员专用）"""
    if not check_admin(request):
        return render(request, 'exam/error.html', {'msg': '您没有权限访问此页面，请联系管理员'})

    if request.method == 'GET':
        return render(request, 'exam/import_exam.html')

    if request.method != 'POST':
        return JsonResponse({'status': 'error', 'msg': '仅支持 POST 上传'})

    uploaded_file = request.FILES.get('file')
    if not uploaded_file:
        return JsonResponse({'status': 'error', 'msg': '请上传文件'})

    filename = uploaded_file.name.lower()
    import_mode = request.POST.get('mode', 'bank')
    exam_title = request.POST.get('exam_title', '').strip()
    exam_time = int(request.POST.get('exam_time', 30) or 30)
    exam_pass = int(request.POST.get('exam_pass', 60) or 60)

    try:
        if filename.endswith('.csv'):
            questions_data = _parse_template_csv(uploaded_file)
        elif filename.endswith(('.xlsx', '.xls')):
            if not HAS_OPENPYXL:
                return JsonResponse({'status': 'error', 'msg': '服务器未安装 openpyxl'})
            questions_data = _parse_template_excel(uploaded_file)
        else:
            return JsonResponse({'status': 'error', 'msg': '不支持的文件格式'})
    except Exception as e:
        import traceback
        return JsonResponse({'status': 'error', 'msg': f'文件解析失败: {str(e)}'})

    if not questions_data:
        return JsonResponse({'status': 'error', 'msg': '文件中没有解析到有效题目'})

    bank_count = 0
    for q_data in questions_data:
        try:
            QuestionBank.objects.create(
                q_type=q_data['q_type'],
                content=q_data['content'],
                options=q_data['options'],
                correct_answer=q_data['correct_answer'],
                tag=q_data.get('tag', ''),
                analysis=q_data.get('analysis', ''),
            )
            bank_count += 1
        except Exception as e:
            print(f"题库导入失败: {e}")
            continue

    # 统计选项情况
    questions_with_options = sum(1 for q in questions_data if q['options'])
    questions_without_options = len(questions_data) - questions_with_options

    result = {
        'status': 'ok',
        'bank_count': bank_count,
        'debug': {
            'total_parsed': len(questions_data),
            'with_options': questions_with_options,
            'without_options': questions_without_options,
        }
    }

    if import_mode == 'exam' and exam_title:
        exam = Exam.objects.create(
            title=exam_title,
            description=f'从题库导入生成，共{len(questions_data)}题',
            time_limit=exam_time,
            pass_score=exam_pass,
            total_score=sum(q.get('score', 5) for q in questions_data),
        )

        question_count = 0
        for idx, q_data in enumerate(questions_data, 1):
            try:
                Question.objects.create(
                    exam=exam,
                    q_type=q_data['q_type'],
                    content=q_data['content'],
                    options=q_data['options'],
                    correct_answer=q_data['correct_answer'],
                    score=q_data.get('score', 5),
                    order=idx,
                    tag=q_data.get('tag', ''),
                    analysis=q_data.get('analysis', ''),
                )
                question_count += 1
            except Exception as e:
                print(f"考试题目创建失败: {e}")
                continue

        result['exam_id'] = exam.id
        result['exam_title'] = exam.title
        result['exam_question_count'] = question_count
        result['msg'] = f'成功导入题库 {bank_count} 题，并创建考试「{exam_title}」共 {question_count} 题'
    else:
        result['msg'] = f'成功导入题库 {bank_count} 题'

    return JsonResponse(result)


def _parse_template_csv(uploaded_file):
    data = []
    content = uploaded_file.read().decode('utf-8-sig')
    reader = csv.DictReader(io.StringIO(content))

    type_map = {
        '单选题': 'single', '多选题': 'multi', '判断题': 'judge',
        '填空题': 'fill', '问答题': 'essay',
        'single': 'single', 'multi': 'multi', 'judge': 'judge',
        'fill': 'fill', 'essay': 'essay',
    }

    for row in reader:
        raw_type = (row.get('题型（必选）', '') or row.get('题型', '')).strip()
        q_type = type_map.get(raw_type, 'single')

        options = {}
        for opt_letter in 'ABCDEFGHIJ':
            col_name = f'选项{opt_letter}'
            val = row.get(col_name, '').strip()
            if val:
                options[opt_letter] = val

        if q_type == 'judge' and not options:
            options = {'A': '正确', 'B': '错误'}

        data.append({
            'q_type': q_type,
            'content': (row.get('题干（必填）', '') or row.get('题干', '')).strip(),
            'correct_answer': (row.get('答案（必填）', '') or row.get('答案', '')).strip(),
            'analysis': (row.get('答案解析（选填）', '') or row.get('答案解析', '')).strip(),
            'tag': (row.get('标签（仅导入题库时有效）', '') or row.get('标签', '')).strip(),
            'score': int(float(row.get('分数（导入试卷时必填）', row.get('分数', '5')) or '5')),
            'options': options,
        })

    return [d for d in data if d['content']]


def _parse_template_excel(uploaded_file):
    """解析用户实体模板 Excel - 精确匹配结构"""
    import openpyxl

    data = []
    wb = openpyxl.load_workbook(io.BytesIO(uploaded_file.read()), data_only=True)
    ws = wb.active

    type_map = {
        '单选题': 'single', '多选题': 'multi', '判断题': 'judge',
        '填空题': 'fill', '问答题': 'essay',
    }

    # 用户模板结构：
    # 第1行：填写注意事项
    # 第2行：表头（题型、题干、答案、答案解析、标签、分数、选项A~J）
    # 第3行开始：数据

    HEADER_ROW = 2
    DATA_START_ROW = 3

    # 固定列映射（根据用户模板）
    col_map = {
        'type': 1,      # A列：题型
        'content': 2,   # B列：题干
        'answer': 3,    # C列：答案
        'analysis': 4,  # D列：答案解析
        'tag': 5,       # E列：标签
        'score': 6,     # F列：分数
        'opt_A': 7,     # G列：选项A
        'opt_B': 8,     # H列：选项B
        'opt_C': 9,     # I列：选项C
        'opt_D': 10,    # J列：选项D
        'opt_E': 11,    # K列：选项E
        'opt_F': 12,    # L列：选项F
        'opt_G': 13,    # M列：选项G
        'opt_H': 14,    # N列：选项H
        'opt_I': 15,    # O列：选项I
        'opt_J': 16,    # P列：选项J
    }

    print(f"[IMPORT] 使用固定模板结构：表头第{HEADER_ROW}行，数据第{DATA_START_ROW}行开始")

    # 读取数据行
    for row_idx in range(DATA_START_ROW, ws.max_row + 1):
        # 读取题型和题干（关键列）
        type_cell = ws.cell(row=row_idx, column=col_map['type'])
        content_cell = ws.cell(row=row_idx, column=col_map['content'])

        raw_type = str(type_cell.value or '').strip()
        content = str(content_cell.value or '').strip()

        # 跳过空行
        if not raw_type or not content or raw_type == 'None':
            continue

        # 检查是否是表头重复行
        if '题型' in raw_type and '必选' in raw_type:
            continue

        q_type = type_map.get(raw_type, 'single')

        # 收集选项（G~P列）
        options = {}
        for letter in 'ABCDEFGHIJ':
            col_idx = col_map[f'opt_{letter}']
            cell = ws.cell(row=row_idx, column=col_idx)
            val = cell.value
            if val is not None:
                val_str = str(val).strip()
                if val_str and val_str.lower() not in ['none', 'nan', 'null', '']:
                    options[letter] = val_str

        # 判断题默认选项（如果模板没填）
        if q_type == 'judge' and not options:
            options = {'A': '正确', 'B': '错误'}

        # 读取其他字段
        answer_cell = ws.cell(row=row_idx, column=col_map['answer'])
        correct_answer = str(answer_cell.value or '').strip()

        analysis_cell = ws.cell(row=row_idx, column=col_map['analysis'])
        analysis = str(analysis_cell.value or '').strip()

        tag_cell = ws.cell(row=row_idx, column=col_map['tag'])
        tag = str(tag_cell.value or '').strip()

        score_cell = ws.cell(row=row_idx, column=col_map['score'])
        try:
            score = int(float(str(score_cell.value or '5')))
        except:
            score = 5

        data.append({
            'q_type': q_type,
            'content': content,
            'correct_answer': correct_answer,
            'analysis': analysis,
            'tag': tag,
            'score': score,
            'options': options,
        })

    print(f"[IMPORT] 成功解析 {len(data)} 道题目")
    questions_with_options = sum(1 for q in data if q['options'])
    print(f"[IMPORT] 有选项的题目: {questions_with_options}/{len(data)}")

    # 打印前3道题的详情用于调试
    for i, q in enumerate(data[:3]):
        print(f"[IMPORT] 题目{i+1}: {q['content'][:30]}... | 选项数={len(q['options'])} | 选项={list(q['options'].keys())}")

    return data

@csrf_exempt
def generate_exam(request):
    """从题库随机组卷 - 满分100分（管理员专用）"""
    if not check_admin(request):
        return render(request, 'exam/error.html', {'msg': '您没有权限访问此页面，请联系管理员'})

    if request.method == 'GET':
        from django.db.models import Count
        # 获取所有标签及其题目数量统计
        tags = QuestionBank.objects.exclude(tag='').values('tag').annotate(count=Count('id')).order_by('-count')
        total_questions = QuestionBank.objects.count()
        return render(request, 'exam/generate_exam.html', {
            'tags': tags,
            'total_questions': total_questions,
        })

    if request.method != 'POST':
        return JsonResponse({'status': 'error', 'msg': '仅支持 POST'})

    try:
        data = json.loads(request.body)
    except:
        data = request.POST

    exam_title = data.get('exam_title', '').strip()
    if not exam_title:
        return JsonResponse({'status': 'error', 'msg': '请输入考试名称'})

    selected_tags = data.get('tags', [])
    if isinstance(selected_tags, str):
        selected_tags = [t.strip() for t in selected_tags.split(',') if t.strip()]

    single_count = int(data.get('single_count', 10) or 10)
    multi_count = int(data.get('multi_count', 5) or 5)
    judge_count = int(data.get('judge_count', 5) or 5)
    time_limit = int(data.get('time_limit', 60) or 60)
    pass_score = int(data.get('pass_score', 60) or 60)

    bank_query = QuestionBank.objects.all()
    if selected_tags and len(selected_tags) > 0:
        bank_query = bank_query.filter(tag__in=selected_tags)
        print(f"[GENERATE] 筛选标签: {selected_tags}, 可用题目: {bank_query.count()}")

    import random
    single_qs = list(bank_query.filter(q_type='single').order_by('?')[:single_count])
    multi_qs = list(bank_query.filter(q_type='multi').order_by('?')[:multi_count])
    judge_qs = list(bank_query.filter(q_type='judge').order_by('?')[:judge_count])

    all_selected = single_qs + multi_qs + judge_qs
    total_questions = len(all_selected)

    if total_questions == 0:
        return JsonResponse({'status': 'error', 'msg': '题库中没有符合条件的题目，请先导入题库'})

    base_score = 100 // total_questions
    remainder = 100 - (base_score * total_questions)

    exam = Exam.objects.create(
        title=exam_title,
        description=f'随机组卷：单选{len(single_qs)}题 / 多选{len(multi_qs)}题 / 判断{len(judge_qs)}题',
        time_limit=time_limit,
        pass_score=pass_score,
        total_score=100,
    )

    for idx, bank_q in enumerate(all_selected, 1):
        score = base_score + (1 if idx <= remainder else 0)
        Question.objects.create(
            exam=exam,
            q_type=bank_q.q_type,
            content=bank_q.content,
            options=bank_q.options,
            correct_answer=bank_q.correct_answer,
            score=score,
            order=idx,
            tag=bank_q.tag,
            analysis=bank_q.analysis,
        )

    return JsonResponse({
        'status': 'ok',
        'msg': f'成功生成考试「{exam_title}」，共 {total_questions} 题，满分 100 分',
        'exam_id': exam.id,
        'exam_title': exam_title,
        'single_count': len(single_qs),
        'multi_count': len(multi_qs),
        'judge_count': len(judge_qs),
        'total_questions': total_questions,
        'total_score': 100,
    })


@csrf_exempt
def auto_generate_exam(request):
    """一键快速组卷：从题库随机选20题，自动赋分满分100（管理员专用）"""
    if not check_admin(request):
        return JsonResponse({'status': 'error', 'msg': '无权限'})

    if request.method != 'POST':
        return JsonResponse({'status': 'error', 'msg': '仅支持 POST'})

    try:
        data = json.loads(request.body)
    except:
        data = request.POST

    exam_title = data.get('exam_title', '').strip()
    if not exam_title:
        return JsonResponse({'status': 'error', 'msg': '请输入考试名称'})

    single_count = int(data.get('single_count', 10) or 10)
    multi_count = int(data.get('multi_count', 5) or 5)
    judge_count = int(data.get('judge_count', 5) or 5)

    total = single_count + multi_count + judge_count
    if total == 0:
        return JsonResponse({'status': 'error', 'msg': '题目数量不能为0'})

    single_qs = list(QuestionBank.objects.filter(q_type='single').order_by('?')[:single_count])
    multi_qs = list(QuestionBank.objects.filter(q_type='multi').order_by('?')[:multi_count])
    judge_qs = list(QuestionBank.objects.filter(q_type='judge').order_by('?')[:judge_count])

    all_selected = single_qs + multi_qs + judge_qs
    actual_total = len(all_selected)

    if actual_total == 0:
        return JsonResponse({'status': 'error', 'msg': '题库为空，请先导入题目'})

    base_score = 100 // actual_total
    remainder = 100 - (base_score * actual_total)

    exam = Exam.objects.create(
        title=exam_title,
        description=f'随机组卷：单选{len(single_qs)}题 / 多选{len(multi_qs)}题 / 判断{len(judge_qs)}题',
        time_limit=int(data.get('time_limit', 60) or 60),
        pass_score=int(data.get('pass_score', 60) or 60),
        total_score=100,
    )

    for idx, bank_q in enumerate(all_selected, 1):
        score = base_score + (1 if idx <= remainder else 0)
        Question.objects.create(
            exam=exam,
            q_type=bank_q.q_type,
            content=bank_q.content,
            options=bank_q.options,
            correct_answer=bank_q.correct_answer,
            score=score,
            order=idx,
            tag=bank_q.tag,
            analysis=bank_q.analysis,
        )

    return JsonResponse({
        'status': 'ok',
        'msg': f'一键组卷成功！考试「{exam_title}」共 {actual_total} 题，满分 100 分',
        'exam_id': exam.id,
        'single': len(single_qs),
        'multi': len(multi_qs),
        'judge': len(judge_qs),
        'total': actual_total,
    })


# =================== 管理功能 ===================

@csrf_exempt
def init_demo_data(request):
    if Exam.objects.exists():
        return JsonResponse({'status': 'ok', 'msg': '演示数据已存在'})

    exam = Exam.objects.create(
        title='安全生产基础培训考试',
        description='检验员工安全知识掌握程度',
        time_limit=30,
        pass_score=60,
        total_score=50,
    )

    questions = [
        {'q_type': 'single', 'content': '进入施工现场必须佩戴的安全防护用品是？',
         'options': {'A': '安全帽', 'B': '手套', 'C': '护目镜', 'D': '安全鞋'},
         'correct_answer': 'A', 'score': 10, 'order': 1},
        {'q_type': 'single', 'content': '高处作业是指在坠落高度基准面多少米以上进行的作业？',
         'options': {'A': '1米', 'B': '2米', 'C': '3米', 'D': '5米'},
         'correct_answer': 'B', 'score': 10, 'order': 2},
        {'q_type': 'judge', 'content': '特种作业人员必须经专门的安全技术培训并考核合格，取得特种作业操作证后，方可上岗作业。',
         'options': {'A': '正确', 'B': '错误'},
         'correct_answer': 'A', 'score': 10, 'order': 3},
        {'q_type': 'multi', 'content': '以下哪些属于施工现场常见的安全隐患？（多选）',
         'options': {'A': '临边无防护', 'B': '电线裸露', 'C': '通道畅通', 'D': '消防器材缺失'},
         'correct_answer': 'A,B,D', 'score': 10, 'order': 4},
        {'q_type': 'single', 'content': '发现有人触电时，首先应该怎么做？',
         'options': {'A': '立即用手拉开触电者', 'B': '切断电源或使用绝缘工具使触电者脱离电源',
                     'C': '拨打120等待救援', 'D': '用水泼向触电者'},
         'correct_answer': 'B', 'score': 10, 'order': 5},
    ]

    for q in questions:
        Question.objects.create(exam=exam, **q)

    return JsonResponse({
        'status': 'ok',
        'msg': '演示数据初始化成功',
        'exam_id': exam.id,
        'question_count': len(questions),
    })




# =================== 考试人员管理 ===================

def admin_all_records(request):
    """查看所有考试人员的考试记录"""
    if not check_admin(request):
        return redirect('admin_login_page')

    user_name = request.session.get('admin_name', '管理员')

    # 获取所有考试记录，关联考试和题目
    records = ExamRecord.objects.select_related('exam').all().order_by('-created_at')

    # 统计信息
    stats = {
        'total_records': records.count(),
        'total_users': records.values('user_name').distinct().count(),
        'total_exams': Exam.objects.count(),
        'pass_count': records.filter(is_pass=True).count(),
    }

    return render(request, 'exam/admin_all_records.html', {
        'records': records,
        'stats': stats,
    })


def admin_view_record(request, record_id):
    """查看单个考试记录详情"""
    if not check_admin(request):
        return redirect('admin_login_page')

    user_name = request.session.get('admin_name', '管理员')

    record = get_object_or_404(ExamRecord, id=record_id)
    answers = record.answers.select_related('question').all().order_by('question__order')

    return render(request, 'exam/admin_view_record.html', {
        'record': record,
        'answers': answers,
    })


@csrf_exempt
def admin_export_all_pdf(request):
    """批量导出所有考试记录的 PDF"""
    if not check_admin(request):
        return JsonResponse({'status': 'error', 'msg': '无权限'})

    if request.method != 'POST':
        return JsonResponse({'status': 'error', 'msg': '仅支持 POST'})

    try:
        data = json.loads(request.body)
    except:
        data = request.POST

    record_ids = data.get('record_ids', [])
    if not record_ids:
        return JsonResponse({'status': 'error', 'msg': '请选择要导出的记录'})

    # 生成单个 PDF 包含所有选中记录
    return _generate_batch_pdf(record_ids)


def _generate_batch_pdf(record_ids):
    """生成批量 PDF"""
    records = ExamRecord.objects.filter(id__in=record_ids).select_related('exam')

    if not records:
        return HttpResponse('没有可导出的记录', status=400)

    font_paths = [
        '/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc',
        '/usr/share/fonts/truetype/wqy/wqy-microhei.ttc',
        '/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc',
        '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',
    ]

    font_name = 'Helvetica'
    for fp in font_paths:
        if os.path.exists(fp):
            try:
                if 'wqy' in fp or 'Noto' in fp or 'CJK' in fp:
                    pdfmetrics.registerFont(TTFont('ChineseFont', fp, subfontIndex=0))
                    font_name = 'ChineseFont'
                else:
                    pdfmetrics.registerFont(TTFont('CustomFont', fp))
                    font_name = 'CustomFont'
                break
            except Exception as e:
                print(f"字体注册失败 {fp}: {e}")
                continue

    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(
        name='Chinese', fontName=font_name, fontSize=12, leading=20, alignment=TA_LEFT,
    ))
    styles.add(ParagraphStyle(
        name='ChineseCenter', fontName=font_name, fontSize=16, leading=24,
        alignment=TA_CENTER, spaceAfter=12,
    ))
    styles.add(ParagraphStyle(
        name='ChineseSmall', fontName=font_name, fontSize=10, leading=16, alignment=TA_LEFT,
    ))
    styles.add(ParagraphStyle(
        name='ChineseTitle', fontName=font_name, fontSize=14, leading=22,
        alignment=TA_LEFT, spaceAfter=8, textColor=colors.HexColor('#2c5282'),
    ))

    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4, rightMargin=2*cm, leftMargin=2*cm,
                            topMargin=2*cm, bottomMargin=2*cm)

    story = []
    story.append(Paragraph("安全培训考试 - 批量成绩报告", styles['ChineseCenter']))
    story.append(Spacer(1, 0.5*cm))
    story.append(Paragraph(f"生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}", styles['ChineseSmall']))
    story.append(Spacer(1, 0.5*cm))

    for record in records:
        exam = record.exam
        answers = record.answers.select_related('question').all().order_by('question__order')

        # 考生信息卡片
        story.append(Paragraph(f"考生: {record.user_name} | 考试: {exam.title}", styles['ChineseTitle']))

        info_data = [
            ['考生姓名', record.user_name or '未填写'],
            ['手机号码', record.user_phone or '未填写'],
            ['考试时间', record.created_at.strftime('%Y-%m-%d %H:%M')],
            ['考试得分', f"{record.score} 分 / {exam.total_score} 分"],
            ['是否及格', '及格' if record.is_pass else '不及格'],
            ['考试次数', f"第 {record.attempt_number} 次"],
        ]
        info_table = Table(info_data, colWidths=[4*cm, 10*cm])
        info_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (0, -1), colors.lightgrey),
            ('TEXTCOLOR', (0, 0), (-1, -1), colors.black),
            ('ALIGN', (0, 0), (0, -1), 'CENTER'),
            ('ALIGN', (1, 0), (1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (-1, -1), font_name),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
            ('TOPPADDING', (0, 0), (-1, -1), 4),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 4),
        ]))
        story.append(info_table)
        story.append(Spacer(1, 0.3*cm))

        # 签名
        if record.signature:
            try:
                img_path = record.signature.path
                if os.path.exists(img_path):
                    story.append(Paragraph("考生电子签名：", styles['ChineseSmall']))
                    img = Image(img_path, width=4*cm, height=1.5*cm)
                    story.append(img)
                    story.append(Spacer(1, 0.2*cm))
            except:
                pass

        # 答题详情
        story.append(Paragraph("答题详情：", styles['ChineseSmall']))
        for idx, ans in enumerate(answers, 1):
            q = ans.question
            status_color = colors.green if ans.is_correct else colors.red
            status_text = "✓" if ans.is_correct else "✗"
            story.append(Paragraph(
                f"{idx}. [{q.get_q_type_display()}] {q.content[:50]}... "
                f"<font color={status_color.hexval()}>{status_text}</font> "
                f"答案: {ans.user_answer or '未作答'} | 正确答案: {q.correct_answer}",
                styles['ChineseSmall']
            ))

        story.append(Spacer(1, 0.5*cm))
        story.append(Paragraph("—" * 40, styles['ChineseSmall']))
        story.append(Spacer(1, 0.5*cm))

    doc.build(story)
    pdf = buffer.getvalue()
    buffer.close()

    response = HttpResponse(pdf, content_type='application/pdf')
    response['Content-Disposition'] = f'attachment; filename="batch_exam_report_{datetime.now().strftime("%Y%m%d%H%M%S")}.pdf"'
    return response

def health_check(request):
    try:
        with connection.cursor() as cursor:
            cursor.execute("SELECT 1")
            cursor.fetchone()
        db_status = 'ok'
    except Exception as e:
        db_status = f'error: {str(e)}'

    return JsonResponse({
        'status': 'ok',
        'db': db_status,
        'timestamp': datetime.now().isoformat(),
    })
