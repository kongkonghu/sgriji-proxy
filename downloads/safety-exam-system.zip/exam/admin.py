from django.contrib import admin
from .models import Exam, Question, ExamRecord, Answer

@admin.register(Exam)
class ExamAdmin(admin.ModelAdmin):
    list_display = ['title', 'time_limit', 'pass_score', 'question_count', 'created_at']
    search_fields = ['title']

@admin.register(Question)
class QuestionAdmin(admin.ModelAdmin):
    list_display = ['exam', 'q_type', 'content', 'score']
    list_filter = ['exam', 'q_type']

@admin.register(ExamRecord)
class ExamRecordAdmin(admin.ModelAdmin):
    list_display = ['user_name', 'exam', 'score', 'is_pass', 'submitted_at']
    list_filter = ['exam', 'is_pass']

@admin.register(Answer)
class AnswerAdmin(admin.ModelAdmin):
    list_display = ['record', 'question', 'is_correct']
