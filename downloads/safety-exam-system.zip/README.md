# 在线安全培训考试系统

独立部署的 Django 在线安全培训考试系统，支持微信一键登录、手动姓名登录、在线答题、自动阅卷、PDF 试卷下载（含电子签名）。

## 功能特性

- ✅ 微信 OAuth2 一键登录（网页授权）
- ✅ 手动姓名+手机号登录（非微信环境）
- ✅ 在线答题（单选/多选/判断）
- ✅ 自动阅卷、实时显示成绩
- ✅ PDF 试卷下载（含考生信息、电子签名、答题详情）
- ✅ 健康检查接口（云托管/负载均衡）
- ✅ Docker + 微信云托管部署

## 快速部署（微信云托管）

### 1. 创建 MySQL 数据库

在微信云托管控制台创建 MySQL 实例，记录连接信息：
- 内网地址（如 `10.1.x.x`）
- 端口（默认 3306）
- 用户名/密码

创建数据库：
```sql
CREATE DATABASE safety_exam CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

### 2. 配置环境变量

在微信云托管「服务设置」→「环境变量」中添加：

| 变量名 | 说明 | 示例 |
|--------|------|------|
| `MYSQL_HOST` | MySQL 内网地址 | `10.1.108.163` |
| `MYSQL_PORT` | MySQL 端口 | `3306` |
| `MYSQL_USER` | 数据库用户名 | `root` |
| `MYSQL_PASSWORD` | 数据库密码 | `your_password` |
| `MYSQL_DATABASE` | 数据库名 | `safety_exam` |
| `DJANGO_SECRET_KEY` | Django 密钥（随机字符串） | `zxfg...` |
| `WECHAT_APPID` | 微信小程序/公众号 AppID | `wx...` |
| `WECHAT_SECRET` | 微信小程序/公众号 Secret | `...` |
| `DEBUG` | 调试模式 | `False` |

> **注意**：系统同时兼容 `DB_HOST`/`DB_NAME` 等命名方式，与施工日志系统配置保持一致。

### 3. 部署服务

1. 将代码打包上传至微信云托管
2. 构建并发布服务
3. 访问 `https://你的域名/health/` 确认服务正常
4. 访问 `https://你的域名/init-demo/` 初始化演示数据

### 4. 修改最小实例数

在微信云托管「服务设置」→「基础信息」中：
- **最小实例副本数**：改为 `1`（避免 503 冷启动）
- **最大实例副本数**：保持 `5`

## 本地开发

```bash
# 1. 安装依赖
pip install -r requirements.txt

# 2. 配置环境变量（.env 文件或 export）
export DB_HOST=localhost
export DB_PORT=3306
export DB_USER=root
export DB_PASSWORD=123456
export DB_NAME=safety_exam
export SECRET_KEY=dev-key

# 3. 数据库迁移
python manage.py migrate

# 4. 初始化演示数据
python manage.py shell -c "from exam.views import init_demo_data; init_demo_data(None)"

# 5. 启动服务
python manage.py runserver
```

## 微信登录配置

1. 登录 [微信公众平台](https://mp.weixin.qq.com/)
2. 进入「开发」→「开发管理」→「开发设置」
3. 配置 **网页授权域名** 为你的云托管域名
4. 将 `AppID` 和 `AppSecret` 填入环境变量

> 如果未配置微信参数，系统会自动降级为手动登录模式。

## 项目结构

```
safety_exam_system/
├── safety_exam/          # Django 项目配置
│   ├── settings.py       # 设置（兼容多环境变量命名）
│   ├── urls.py           # 路由
│   └── wsgi.py           # WSGI 入口
├── exam/                 # 考试业务应用
│   ├── models.py         # 数据模型
│   ├── views.py          # 视图逻辑
│   ├── urls.py           # URL 路由
│   └── migrations/       # 数据库迁移
├── templates/            # HTML 模板
├── Dockerfile            # 容器构建
├── docker-compose.yml    # 本地编排
└── requirements.txt      # Python 依赖
```

## 常见问题

**Q: 登录时提示 403 Forbidden (CSRF)**  
A: `manual_login` 已添加 `@csrf_exempt`，如仍报错请检查前端请求 Content-Type。

**Q: 服务偶发 503 Service Unavailable**  
A: 将云托管「最小实例副本数」从 0 改为 1。

**Q: PDF 中文显示为乱码**  
A: Dockerfile 已安装文泉驿字体，如仍乱码请检查容器内 `/usr/share/fonts/truetype/wqy/` 是否存在字体文件。

**Q: 数据库连接失败**  
A: 检查环境变量 `MYSQL_HOST` 是否为内网地址（云托管 MySQL 通常使用内网 IP）。

## 技术栈

- Python 3.11 + Django 4.2
- MySQL 8.0（PyMySQL 驱动）
- Gunicorn + WhiteNoise
- ReportLab（PDF 生成）
- 微信 OAuth2 登录
