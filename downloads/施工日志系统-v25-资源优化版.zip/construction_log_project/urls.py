from django.contrib import admin
from django.urls import path, include
from django.views.generic import TemplateView
from django.http import JsonResponse

def health(request):
    return JsonResponse({"status": "ok", "service": "construction-log"})

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/logs/', include('construction_log.urls')),
    path('health/', health),
    path('', TemplateView.as_view(template_name='construction_log_login.html')),
    path('user/', TemplateView.as_view(template_name='construction_log_user.html')),
    path('admin-entry/', TemplateView.as_view(template_name='construction_log_admin.html')),
]
