import pymysql

# 伪装版本号，兼容 MySQL 5.7
pymysql.version_info = (1, 4, 6, 'final', 0)
pymysql.install_as_MySQLdb()