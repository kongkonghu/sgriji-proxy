#!/bin/bash
# ============================================================
# 施工日志系统 - 数据库自动备份脚本
# 建议通过 crontab 每日凌晨2点执行: 0 2 * * * /app/backup/backup.sh
# ============================================================

DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="/app/backups"
LOG_DIR="/app/logs"
DB_NAME="${MYSQL_DATABASE:-construction_log_db}"
DB_USER="${MYSQL_USER:-root}"
DB_PASS="${MYSQL_PASSWORD:-}"
DB_HOST="${MYSQL_HOST:-localhost}"
DB_PORT="${MYSQL_PORT:-3306}"
RETENTION_DAYS=30

# 创建目录
mkdir -p $BACKUP_DIR $LOG_DIR

# 数据库备份
echo "[$DATE] 开始备份数据库 $DB_NAME..." >> $LOG_DIR/backup.log
mysqldump -h$DB_HOST -P$DB_PORT -u$DB_USER -p$DB_PASS     --single-transaction --routines --triggers     --databases $DB_NAME > $BACKUP_DIR/db_${DB_NAME}_${DATE}.sql 2>> $LOG_DIR/backup.log

if [ $? -eq 0 ]; then
    # 压缩备份文件
    gzip -f $BACKUP_DIR/db_${DB_NAME}_${DATE}.sql
    echo "[$DATE] 数据库备份成功: db_${DB_NAME}_${DATE}.sql.gz" >> $LOG_DIR/backup.log
else
    echo "[$DATE] 数据库备份失败!" >> $LOG_DIR/backup.log
fi

# 备份静态文件和上传文件（如有）
if [ -d "/app/static" ]; then
    tar czf $BACKUP_DIR/static_${DATE}.tar.gz -C /app static 2>/dev/null
fi

# 清理旧备份（保留30天）
find $BACKUP_DIR -name "db_*.sql.gz" -mtime +$RETENTION_DAYS -delete
find $BACKUP_DIR -name "static_*.tar.gz" -mtime +$RETENTION_DAYS -delete
find $LOG_DIR -name "django_error.log.*" -mtime +$RETENTION_DAYS -delete
find $LOG_DIR -name "audit.log.*" -mtime +$RETENTION_DAYS -delete

echo "[$DATE] 备份任务完成，已清理 $RETENTION_DAYS 天前旧文件" >> $LOG_DIR/backup.log
