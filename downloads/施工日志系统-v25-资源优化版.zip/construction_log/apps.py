from django.apps import AppConfig

class ConstructionLogConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'construction_log'
    verbose_name = '施工日志'
