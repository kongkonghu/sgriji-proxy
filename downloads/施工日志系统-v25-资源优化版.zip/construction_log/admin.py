from django.contrib import admin
from .models import ConstructionLog, WeChatUser, OperationLog, LogVersion

@admin.register(ConstructionLog)
class ConstructionLogAdmin(admin.ModelAdmin):
    list_display = ['project_name', 'log_date', 'recorder', 'creator_name', 'is_deleted', 'updated_at']
    list_filter = ['is_deleted', 'project_name', 'log_date']
    search_fields = ['project_name', 'recorder', 'creator_name']
    date_hierarchy = 'log_date'

@admin.register(WeChatUser)
class WeChatUserAdmin(admin.ModelAdmin):
    list_display = ['openid', 'name', 'is_admin', 'staff_id', 'created_at']
    list_filter = ['is_admin']
    search_fields = ['openid', 'name', 'staff_id']

@admin.register(OperationLog)
class OperationLogAdmin(admin.ModelAdmin):
    list_display = ['created_at', 'action', 'user_name', 'project_name', 'log_date', 'ip_address', 'entry_type']
    list_filter = ['action', 'entry_type', 'created_at']
    search_fields = ['user_name', 'project_name', 'detail']
    date_hierarchy = 'created_at'
    readonly_fields = [f.name for f in OperationLog._meta.fields]

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return request.user.is_superuser

@admin.register(LogVersion)
class LogVersionAdmin(admin.ModelAdmin):
    list_display = ['log', 'version_no', 'editor_name', 'change_summary', 'created_at']
    list_filter = ['log__project_name', 'created_at']
    search_fields = ['project_name', 'editor_name', 'change_summary']
    date_hierarchy = 'created_at'
    readonly_fields = [f.name for f in LogVersion._meta.fields]

    def has_add_permission(self, request):
        return False

    def has_change_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return request.user.is_superuser
