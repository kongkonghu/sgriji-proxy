from django.urls import path
from . import views

app_name = 'construction_log'

urlpatterns = [
    path('', views.api_logs, name='api_logs'),
    path('<int:pk>/', views.api_log_item, name='api_log_item'),
    path('<int:pk>/restore/', views.api_log_restore, name='api_log_restore'),
    path('<int:pk>/hard/', views.api_log_hard_delete, name='api_log_hard_delete'),
    path('recycle/', views.api_log_recycle_bin, name='api_log_recycle_bin'),
    path('batch-restore/', views.api_batch_restore, name='api_batch_restore'),
    path('projects/', views.api_log_projects, name='api_log_projects'),
    path('export-zip/', views.api_export_project_zip, name='api_export_project_zip'),
    path('export/excel/', views.api_export_excel, name='api_export_excel'),
    path('auth/wechat/', views.api_wechat_login, name='api_wechat_login'),
    path('auth/user/', views.api_user_info, name='api_user_info'),
    path('auth/admin/', views.api_admin_login, name='api_admin_login'),
    path('auto-create/', views.api_auto_create_log, name='api_auto_create_log'),
    path('backfill/', views.api_create_backfill_log, name='api_create_backfill_log'),
    path('init-db/', views.api_init_db, name='api_init_db'),
    path('reset-admin/', views.api_reset_admin, name='api_reset_admin'),
    # 数据安全保障新增接口
    path('health/', views.api_health_check, name='api_health_check'),
    path('audit-logs/', views.api_audit_logs, name='api_audit_logs'),
    # 版本历史与回滚
    path('<int:pk>/versions/', views.api_log_versions, name='api_log_versions'),
    path('<int:pk>/rollback/', views.api_log_rollback, name='api_log_rollback'),
]
