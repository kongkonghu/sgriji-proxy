from django.db import models

class WeChatUser(models.Model):
    openid = models.CharField('微信openid', max_length=100, unique=True, db_index=True)
    unionid = models.CharField('unionid', max_length=100, blank=True)
    nickname = models.CharField('微信昵称', max_length=100, blank=True)
    name = models.CharField('真实姓名', max_length=50, blank=True)
    avatar = models.URLField('头像', blank=True)
    phone = models.CharField('手机号', max_length=20, blank=True)
    is_admin = models.BooleanField('是否管理员', default=False, help_text='管理员可查看、删除、修改所有日志')
    staff_id = models.CharField('工号/标识', max_length=50, blank=True, db_index=True, help_text='非微信用户可用工号作为身份标识')
    created_at = models.DateTimeField('创建时间', auto_now_add=True)

    class Meta:
        verbose_name = '微信用户'
        verbose_name_plural = '微信用户'

    def __str__(self):
        admin_tag = ' [管理员]' if self.is_admin else ''
        return (self.name or self.nickname or self.openid[:16]) + admin_tag


class ConstructionLog(models.Model):
    project_name = models.CharField('工程名称', max_length=200, db_index=True)
    log_date = models.DateField('记录日期', db_index=True)
    construction_unit = models.CharField('施工单位', max_length=200, default='中国石油天然气管道第二工程有限公司')
    weather_location = models.CharField('天气地点编码', max_length=20, default='610802')
    weather_day = models.CharField('白天天气', max_length=50, blank=True)
    weather_night = models.CharField('夜间天气', max_length=50, blank=True)
    wind_level = models.CharField('风力', max_length=50, blank=True)
    temp_high = models.CharField('最高温度', max_length=10, blank=True)
    temp_low = models.CharField('最低温度', max_length=10, blank=True)
    weather_remark = models.CharField('天气备注', max_length=200, blank=True)

    special_situation = models.TextField('1.停水停电停工待料', blank=True)
    study_prepare = models.TextField('2.图纸规范学习施工准备', blank=True)
    progress = models.TextField('3.项目进度作业内容', blank=True)
    machinery = models.TextField('4.机械班组人员', blank=True)
    in_out = models.TextField('5.人员材料机械进出场', blank=True)
    other_problems = models.TextField('6.其他问题', blank=True)

    scheme_review = models.TextField('1.方案交底审核', blank=True)
    design_review = models.TextField('2.设计交底图纸会审', blank=True)
    contact_sheet = models.TextField('3.工程联络单', blank=True)
    material_test = models.TextField('4.原材料复检', blank=True)
    quality_check = models.TextField('5.质量检查', blank=True)
    hidden_check = models.TextField('6.隐蔽验收', blank=True)
    acceptance = models.TextField('7.验收情况', blank=True)
    inspection = models.TextField('8.上级检查大事记', blank=True)
    meeting = models.TextField('9.会议', blank=True)
    quality_safety = models.TextField('10.质量安全问题整改', blank=True)
    special_method = models.TextField('11.特殊施工方法', blank=True)
    visa = models.TextField('12.签证认质认价', blank=True)
    activities = models.TextField('13.当日活动', blank=True)
    accident = models.TextField('14.事故记录', blank=True)

    recorder = models.CharField('记录人', max_length=50, blank=True)
    record_date = models.DateField('记录日期2', null=True, blank=True)
    merge_count = models.IntegerField('合并次数', default=1)

    creator_openid = models.CharField('创建人openid', max_length=100, blank=True, db_index=True)
    creator_name = models.CharField('创建人姓名', max_length=50, blank=True)
    created_at = models.DateTimeField('创建时间', auto_now_add=True)
    updated_at = models.DateTimeField('更新时间', auto_now=True)

    is_deleted = models.BooleanField('已删除', default=False, db_index=True)
    deleted_at = models.DateTimeField('删除时间', null=True, blank=True)
    deleted_by = models.CharField('删除人', max_length=50, blank=True)

    class Meta:
        verbose_name = '施工日志'
        verbose_name_plural = '施工日志'
        ordering = ['-log_date', '-updated_at']

    def __str__(self):
        return f'{self.project_name} - {self.log_date}'

class OperationLog(models.Model):
    """操作审计日志：记录所有增删改操作，用于追溯和安全审计"""
    ACTION_CHOICES = [
        ('CREATE', '创建'), ('UPDATE', '修改'), ('MERGE', '合并保存'),
        ('SOFT_DELETE', '删除到回收站'), ('RESTORE', '从回收站恢复'),
        ('HARD_DELETE', '彻底删除'), ('EXPORT', '导出'), ('LOGIN', '登录'),
        ('AUTO_CREATE', '自动生成'), ('BACKFILL', '补录创建'),
    ]

    user_openid = models.CharField('操作人openid', max_length=100, blank=True, db_index=True)
    user_name = models.CharField('操作人姓名', max_length=50, blank=True)
    action = models.CharField('操作类型', max_length=20, choices=ACTION_CHOICES, db_index=True)
    project_name = models.CharField('工程名称', max_length=200, blank=True, db_index=True)
    log_date = models.DateField('记录日期', null=True, blank=True)
    log_id = models.BigIntegerField('日志ID', null=True, blank=True, db_index=True)
    detail = models.TextField('操作详情', blank=True, help_text='JSON格式记录变更前后内容摘要')
    ip_address = models.GenericIPAddressField('IP地址', null=True, blank=True)
    user_agent = models.CharField('设备信息', max_length=300, blank=True)
    entry_type = models.CharField('入口类型', max_length=10, blank=True, help_text='user/admin')
    created_at = models.DateTimeField('操作时间', auto_now_add=True, db_index=True)

    class Meta:
        verbose_name = '操作审计日志'
        verbose_name_plural = '操作审计日志'
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['project_name', 'log_date', 'created_at']),
            models.Index(fields=['user_openid', 'created_at']),
            models.Index(fields=['action', 'created_at']),
        ]

    def __str__(self):
        return f"[{self.created_at.strftime('%m-%d %H:%M')}] {self.get_action_display()} - {self.project_name or '系统'}"

class LogVersion(models.Model):
    """施工日志版本历史：每次修改自动保存快照，支持回滚到任意历史版本"""
    log = models.ForeignKey(ConstructionLog, on_delete=models.CASCADE, related_name='versions', verbose_name='关联日志')
    version_no = models.PositiveIntegerField('版本号', default=1, db_index=True)

    # 完整字段快照
    project_name = models.CharField('工程名称', max_length=200)
    log_date = models.DateField('记录日期')
    construction_unit = models.CharField('施工单位', max_length=200, default='中国石油天然气管道第二工程有限公司')
    weather_location = models.CharField('天气地点编码', max_length=20, default='610802')
    weather_day = models.CharField('白天天气', max_length=50, blank=True)
    weather_night = models.CharField('夜间天气', max_length=50, blank=True)
    wind_level = models.CharField('风力', max_length=50, blank=True)
    temp_high = models.CharField('最高温度', max_length=10, blank=True)
    temp_low = models.CharField('最低温度', max_length=10, blank=True)
    weather_remark = models.CharField('天气备注', max_length=200, blank=True)

    special_situation = models.TextField('1.停水停电停工待料', blank=True)
    study_prepare = models.TextField('2.图纸规范学习施工准备', blank=True)
    progress = models.TextField('3.项目进度作业内容', blank=True)
    machinery = models.TextField('4.机械班组人员', blank=True)
    in_out = models.TextField('5.人员材料机械进出场', blank=True)
    other_problems = models.TextField('6.其他问题', blank=True)

    scheme_review = models.TextField('1.方案交底审核', blank=True)
    design_review = models.TextField('2.设计交底图纸会审', blank=True)
    contact_sheet = models.TextField('3.工程联络单', blank=True)
    material_test = models.TextField('4.原材料复检', blank=True)
    quality_check = models.TextField('5.质量检查', blank=True)
    hidden_check = models.TextField('6.隐蔽验收', blank=True)
    acceptance = models.TextField('7.验收情况', blank=True)
    inspection = models.TextField('8.上级检查大事记', blank=True)
    meeting = models.TextField('9.会议', blank=True)
    quality_safety = models.TextField('10.质量安全问题整改', blank=True)
    special_method = models.TextField('11.特殊施工方法', blank=True)
    visa = models.TextField('12.签证认质认价', blank=True)
    activities = models.TextField('13.当日活动', blank=True)
    accident = models.TextField('14.事故记录', blank=True)

    recorder = models.CharField('记录人', max_length=50, blank=True)
    record_date = models.DateField('记录日期2', null=True, blank=True)

    # 版本元信息
    editor_openid = models.CharField('修改人openid', max_length=100, blank=True, db_index=True)
    editor_name = models.CharField('修改人姓名', max_length=50, blank=True)
    change_summary = models.TextField('变更摘要', blank=True, help_text='记录本次修改了哪些字段')
    ip_address = models.GenericIPAddressField('IP地址', null=True, blank=True)
    created_at = models.DateTimeField('版本创建时间', auto_now_add=True, db_index=True)

    class Meta:
        verbose_name = '日志版本历史'
        verbose_name_plural = '日志版本历史'
        ordering = ['-version_no']
        unique_together = [['log', 'version_no']]
        indexes = [
            models.Index(fields=['log', 'version_no']),
            models.Index(fields=['editor_openid', 'created_at']),
        ]

    def __str__(self):
        return f"{self.project_name} - {self.log_date} - v{self.version_no} ({self.editor_name or '系统'})"
