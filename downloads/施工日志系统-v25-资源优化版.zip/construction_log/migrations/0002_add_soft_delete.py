# Generated manually for soft delete and project features

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('construction_log', '0001_initial'),
    ]

    operations = [
        migrations.AddField(
            model_name='constructionlog',
            name='is_deleted',
            field=models.BooleanField(db_index=True, default=False, verbose_name='已删除'),
        ),
        migrations.AddField(
            model_name='constructionlog',
            name='deleted_at',
            field=models.DateTimeField(blank=True, null=True, verbose_name='删除时间'),
        ),
        migrations.AddField(
            model_name='constructionlog',
            name='deleted_by',
            field=models.CharField(blank=True, max_length=50, verbose_name='删除人'),
        ),
    ]
