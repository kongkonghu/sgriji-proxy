# Generated manually for adding user admin fields
from django.db import migrations, models

class Migration(migrations.Migration):
    dependencies = [
        ('construction_log', '0002_add_soft_delete'),
    ]
    operations = [
        migrations.AddField(
            model_name='wechatuser',
            name='is_admin',
            field=models.BooleanField(default=False, help_text='管理员可查看、删除、修改所有日志', verbose_name='是否管理员'),
        ),
        migrations.AddField(
            model_name='wechatuser',
            name='staff_id',
            field=models.CharField(blank=True, db_index=True, help_text='非微信用户可用工号作为身份标识', max_length=50, verbose_name='工号/标识'),
        ),
    ]
